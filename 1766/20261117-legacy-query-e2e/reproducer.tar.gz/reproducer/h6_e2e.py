"""INVESTIGATION-ONLY end-to-end harness for temporalio/sdk-rust#1766 hypothesis H6.

Real Temporal dev server (CLI 1.5.1 / Server 1.29.1) + real Python SDK worker (temporalio 1.34.0).

Harness controls (none of them live inside workflow code):
  * GatedSupplier: a CustomSlotSupplier. Core must reserve a workflow slot before every poll, so
    the harness decides when the worker may poll the sticky / non-sticky queue.
  * TracingRunner: wraps the default SandboxedWorkflowRunner. Logs every activation's jobs and
    the completion's commands at the lang boundary, and can hold the FIRST activation of the
    main workflow open (WFT1 stays "started" on the server) until the harness releases it.
Ordering evidence comes from the trace + the exported history, not from waits.
"""

import argparse
import asyncio
import json
import sys
import threading
import time
import uuid
from datetime import timedelta
from pathlib import Path

import temporalio
from temporalio import workflow
from temporalio.api.enums.v1 import EventType, UpdateWorkflowExecutionLifecycleStage
from temporalio.api.update.v1 import UpdateRef, WaitPolicy
from temporalio.api.common.v1 import WorkflowExecution
from temporalio.api.workflowservice.v1 import PollWorkflowExecutionUpdateRequest
from temporalio.client import Client, WorkflowHistory
from temporalio.service import RPCError, RPCStatusCode
from temporalio.worker import (
    CustomSlotSupplier,
    FixedSizeSlotSupplier,
    Replayer,
    SlotPermit,
    SlotReserveContext,
    Worker,
    WorkerTuner,
)
from temporalio.worker.workflow_sandbox import SandboxedWorkflowRunner
from temporalio.worker._workflow_instance import WorkflowInstance, WorkflowRunner


# ---------------------------------------------------------------- application (unchanged per case)
@workflow.defn
class MemoUpdateWorkflow:
    def __init__(self) -> None:
        self.progress = 0

    @workflow.run
    async def run(self, target_id: str) -> None:
        await workflow.get_external_workflow_handle(target_id).signal("wake")
        workflow.upsert_memo({"progress": 1})
        self.progress = 1
        await workflow.wait_condition(lambda: False)

    @workflow.update
    def add(self, value: int) -> int:
        return value

    @workflow.query
    def get_progress(self) -> int:
        return self.progress


# ---------------------------------------------------------------- trace
T0 = time.monotonic()
TRACE: list[dict] = []
TRACE_LOCK = threading.Lock()


def trace(kind: str, **kw) -> None:
    with TRACE_LOCK:
        rec = {"seq": len(TRACE), "t_ms": round((time.monotonic() - T0) * 1000, 1), "kind": kind, **kw}
        TRACE.append(rec)
    print(f"[h6] {json.dumps(rec)}", flush=True)


# ---------------------------------------------------------------- slot gate
class GatedSupplier(CustomSlotSupplier):
    def __init__(self) -> None:
        self.budget = {False: 1, True: 0}  # first non-sticky poll (WFT#1) allowed
        self.unlimited = {False: False, True: False}
        self.cond: asyncio.Condition | None = None

    def _c(self) -> asyncio.Condition:
        if self.cond is None:
            self.cond = asyncio.Condition()
        return self.cond

    async def reserve_slot(self, ctx: SlotReserveContext) -> SlotPermit:
        if ctx.slot_type != "workflow":
            return SlotPermit()
        k = bool(ctx.is_sticky)
        c = self._c()
        async with c:
            await c.wait_for(lambda: self.unlimited[k] or self.budget[k] > 0)
            if not self.unlimited[k]:
                self.budget[k] -= 1
        trace("slot_reserved", sticky=k)
        return SlotPermit()

    def try_reserve_slot(self, ctx: SlotReserveContext):
        return None

    def mark_slot_used(self, ctx) -> None:
        si = ctx.slot_info
        trace("slot_used", workflow_type=getattr(si, "workflow_type", None), sticky=getattr(si, "is_sticky", None))

    def release_slot(self, ctx) -> None:
        pass

    async def grant(self, sticky: bool, n: int = 1) -> None:
        c = self._c()
        async with c:
            self.budget[sticky] += n
            c.notify_all()
        trace("gate_grant", sticky=sticky, n=n)

    async def open_all(self) -> None:
        c = self._c()
        async with c:
            self.unlimited = {False: True, True: True}
            c.notify_all()
        trace("gate_open_all")


# ---------------------------------------------------------------- tracing runner
class TracingInstance(WorkflowInstance):
    def __init__(self, inner: WorkflowInstance, wf_id: str, runner: "TracingRunner") -> None:
        self.inner, self.wf_id, self.runner = inner, wf_id, runner

    def activate(self, act):
        jobs = [j.WhichOneof("variant") for j in act.jobs]
        query_ids = [j.query_workflow.query_id for j in act.jobs if j.HasField("query_workflow")]
        trace("activation", wf=self.wf_id, run=act.run_id[:8], is_replaying=act.is_replaying,
              history_length=act.history_length, jobs=jobs, query_ids=query_ids,
              lang_flags=list(act.available_internal_flags))
        comp = self.inner.activate(act)
        cmds = []
        if comp.HasField("successful"):
            for c in comp.successful.commands:
                v = c.WhichOneof("variant")
                if v == "update_response":
                    v = f"update_response.{c.update_response.WhichOneof('response')}"
                cmds.append(v)
        else:
            cmds = ["FAILED:" + comp.failed.failure.message[:200]]
        trace("completion", wf=self.wf_id, commands=cmds)
        if (self.runner.hold_first and not act.is_replaying and "initialize_workflow" in jobs
                and self.wf_id == self.runner.main_id):
            self.runner.hold_first = False
            trace("wft1_held_open")
            self.runner.loop.call_soon_threadsafe(self.runner.wft1_held.set)
            self.runner.release.wait()
            trace("wft1_released")
        return comp

    def get_serialization_context(self, *a, **kw):
        return self.inner.get_serialization_context(*a, **kw)

    def get_external_store_context(self, *a, **kw):
        return self.inner.get_external_store_context(*a, **kw)

    def get_info(self):
        return self.inner.get_info()

    def get_thread_id(self):
        return self.inner.get_thread_id()


class TracingRunner(WorkflowRunner):
    def __init__(self, inner: WorkflowRunner, loop, main_id: str, hold_first: bool) -> None:
        self.inner, self.loop, self.main_id, self.hold_first = inner, loop, main_id, hold_first
        self.wft1_held = asyncio.Event()
        self.release = threading.Event()

    def prepare_workflow(self, defn) -> None:
        self.inner.prepare_workflow(defn)

    def create_instance(self, det) -> WorkflowInstance:
        return TracingInstance(self.inner.create_instance(det), det.info.workflow_id, self)

    def set_worker_level_failure_exception_types(self, types) -> None:
        self.inner.set_worker_level_failure_exception_types(types)


# ---------------------------------------------------------------- helpers
async def history_types(client: Client, wf_id: str):
    h = await client.get_workflow_handle(wf_id).fetch_history()
    return h, [(e.event_id, EventType.Name(e.event_type).removeprefix("EVENT_TYPE_")) for e in h.events]


async def wait_for_ack_and_wft(client: Client, wf_id: str) -> list:
    # Observable server state: ExternalWorkflowExecutionSignaled followed by WorkflowTaskScheduled.
    while True:
        _, ev = await history_types(client, wf_id)
        names = [n for _, n in ev]
        if "EXTERNAL_WORKFLOW_EXECUTION_SIGNALED" in names:
            i = names.index("EXTERNAL_WORKFLOW_EXECUTION_SIGNALED")
            if "WORKFLOW_TASK_SCHEDULED" in names[i:]:
                trace("server_state_ack_and_wft_scheduled", events=ev)
                return ev
        await asyncio.sleep(0.05)  # polling an observable condition, not used as ordering proof


async def wait_update_admitted(client: Client, wf_id: str, update_id: str) -> None:
    req = PollWorkflowExecutionUpdateRequest(
        namespace=client.namespace,
        update_ref=UpdateRef(workflow_execution=WorkflowExecution(workflow_id=wf_id), update_id=update_id),
        identity="h6-harness",
        wait_policy=WaitPolicy(lifecycle_stage=UpdateWorkflowExecutionLifecycleStage.UPDATE_WORKFLOW_EXECUTION_LIFECYCLE_STAGE_ADMITTED),
    )
    while True:
        try:
            resp = await client.workflow_service.poll_workflow_execution_update(req, timeout=timedelta(seconds=2))
            trace("server_state_update_stage", stage=UpdateWorkflowExecutionLifecycleStage.Name(resp.stage))
            return
        except RPCError as e:
            if e.status in (RPCStatusCode.NOT_FOUND, RPCStatusCode.DEADLINE_EXCEEDED, RPCStatusCode.CANCELLED):
                await asyncio.sleep(0.05)
                continue
            raise


# ---------------------------------------------------------------- one case
async def run_case(addr: str, case: str, outdir: Path, cache: int, sticky_timeout_s: float) -> dict:
    client = await Client.connect(addr)
    loop = asyncio.get_running_loop()
    tag = uuid.uuid4().hex[:8]
    main_id, target_id, tq = f"h6-{case}-{tag}", f"signal-target-{tag}", f"h6-tq-{tag}"
    send_query = case in ("S_query", "S_query_early", "N_ungated", "C1_trailing_query", "C2_wft_before_query", "C4_uncached", "C5_sticky_fallback")
    trace("case_start", case=case, addr=addr, cache=cache, main_id=main_id,
          temporalio=temporalio.__version__, sticky_timeout_s=sticky_timeout_s)

    # Target exists but has no worker: it can still receive the external signal.
    await client.start_workflow("SignalTarget", id=target_id, task_queue=f"no-worker-{tag}")

    gate = GatedSupplier()
    tuner = WorkerTuner.create_composite(
        workflow_supplier=gate,
        activity_supplier=FixedSizeSlotSupplier(5),
        local_activity_supplier=FixedSizeSlotSupplier(5),
        nexus_supplier=FixedSizeSlotSupplier(5),
    )
    runner = TracingRunner(SandboxedWorkflowRunner(), loop, main_id, hold_first=send_query)
    worker = Worker(
        client, task_queue=tq, workflows=[MemoUpdateWorkflow], tuner=tuner,
        workflow_runner=runner, max_cached_workflows=cache, debug_mode=False,
        max_concurrent_workflow_task_polls=2,
        sticky_queue_schedule_to_start_timeout=timedelta(seconds=sticky_timeout_s),
    )
    result: dict = {"case": case, "main_id": main_id}
    async with worker:
        if case == "N_ungated":
            await gate.open_all()  # ordinary worker: both pollers active the whole time
        handle = await client.start_workflow(MemoUpdateWorkflow.run, target_id, id=main_id, task_queue=tq)
        query_task = None
        if send_query:
            await runner.wft1_held.wait()  # WFT#1 is started on the server and held open
            trace("client_query_sent_while_wft1_started")
            query_task = asyncio.create_task(handle.query(MemoUpdateWorkflow.get_progress))
            # Pacing only (must stay below Python's 2s deadlock detector): give the query RPC time
            # to reach the server before WFT#1 completes. The path the query actually took is
            # classified afterwards from the trace (legacy_query vs. attached query id).
            await asyncio.sleep(0.5)
            runner.release.set()
            if case == "S_query_early":
                # Control: let the non-sticky poll happen right away, racing the ack.
                await gate.grant(sticky=False, n=1)
                trace("client_query_returned", value=await query_task)

        await wait_for_ack_and_wft(client, main_id)

        update_id = f"upd-{tag}"

        async def do_update():
            return await handle.execute_update(MemoUpdateWorkflow.add, 7, id=update_id)

        if case in ("S_query_early", "N_ungated"):
            upd = asyncio.create_task(do_update())
            await wait_update_admitted(client, main_id, update_id)
            await gate.open_all()
            if case == "N_ungated":
                trace("client_query_returned", value=await query_task)
            result["update_result"] = await upd
        elif case in ("S_query", "S_noquery"):
            # Sticky poller is never granted (stalled sticky worker). Update admitted while WFT#2 is
            # scheduled, then ONE non-sticky poll: matching decides whether the queued legacy query
            # or WFT#2 is handed out first. The trace records which.
            upd = asyncio.create_task(do_update())
            await wait_update_admitted(client, main_id, update_id)
            await gate.grant(sticky=False, n=1)
            pending = {upd} | ({query_task} if query_task else set())
            done, _ = await asyncio.wait(pending, return_when=asyncio.FIRST_COMPLETED)
            trace("first_finished", which=["query" if t is query_task else "update" for t in done])
            await gate.open_all()
            if query_task:
                trace("client_query_returned", value=await query_task)
            result["update_result"] = await upd
        elif case == "C4_uncached":
            # No sticky queue when uncached: query and WFT#2 share the normal queue. Update is
            # admitted first so WFT#2 carries it whichever task matching hands out first.
            upd = asyncio.create_task(do_update())
            await wait_update_admitted(client, main_id, update_id)
            await gate.open_all()
            q = await query_task
            trace("client_query_returned", value=q)
            result["update_result"] = await upd
        elif case in ("C1_trailing_query", "C5_sticky_fallback"):
            # Let exactly one non-sticky poll happen: the queued legacy query.
            await gate.grant(sticky=False, n=1)
            q = await query_task
            trace("client_query_returned", value=q)
            upd = asyncio.create_task(do_update())
            await wait_update_admitted(client, main_id, update_id)
            await gate.open_all()
            result["update_result"] = await upd
        elif case == "C2_wft_before_query":
            upd = asyncio.create_task(do_update())
            await wait_update_admitted(client, main_id, update_id)
            await gate.grant(sticky=True, n=1)
            result["update_result"] = await upd
            await gate.open_all()
            q = await query_task
            trace("client_query_returned", value=q)
        elif case == "C3_no_query":
            upd = asyncio.create_task(do_update())
            await wait_update_admitted(client, main_id, update_id)
            await gate.open_all()
            result["update_result"] = await upd
        trace("update_result", value=result.get("update_result"))

        hist, ev = await history_types(client, main_id)
        trace("final_history", events=ev)
        (outdir / f"{case}-{tag}.history.json").write_text(hist.to_json())
        await handle.terminate("h6 case done")
        await client.get_workflow_handle(target_id).terminate("h6 case done")

    # Committed-WFT analysis on the exported history.
    events = hist.events
    commits = []
    for i, e in enumerate(events):
        if e.event_type == EventType.EVENT_TYPE_WORKFLOW_TASK_COMPLETED:
            cmds = []
            for f in events[i + 1:]:
                if f.event_type in (EventType.EVENT_TYPE_WORKFLOW_TASK_SCHEDULED,
                                    EventType.EVENT_TYPE_WORKFLOW_EXECUTION_TERMINATED):
                    break
                name = EventType.Name(f.event_type).removeprefix("EVENT_TYPE_")
                link = None
                if f.HasField("workflow_properties_modified_event_attributes"):
                    link = f.workflow_properties_modified_event_attributes.workflow_task_completed_event_id
                if f.HasField("workflow_execution_update_accepted_event_attributes"):
                    link = "seq=" + str(f.workflow_execution_update_accepted_event_attributes.accepted_request_sequencing_event_id)
                cmds.append((f.event_id, name, link))
            commits.append({"wft_completed": e.event_id,
                            "core_flags": list(e.workflow_task_completed_event_attributes.sdk_metadata.core_used_flags),
                            "lang_flags": list(e.workflow_task_completed_event_attributes.sdk_metadata.lang_used_flags),
                            "events": cmds})
    result["commits"] = commits
    trace("committed_wfts", commits=commits)

    # Cold replay of the exact exported history with the same workflow implementation.
    rr = await Replayer(workflows=[MemoUpdateWorkflow]).replay_workflow(
        WorkflowHistory.from_json(main_id, hist.to_json()), raise_on_replay_failure=False)
    result["replay_failure"] = str(rr.replay_failure) if rr.replay_failure else None
    trace("cold_replay", failure=result["replay_failure"])
    return result


async def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--addr", required=True)
    ap.add_argument("--case", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--cache", type=int, default=1000)
    ap.add_argument("--sticky-timeout", type=float, default=60.0)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    res = await asyncio.wait_for(run_case(a.addr, a.case, out, a.cache, a.sticky_timeout), 120)
    (out / f"{a.case}-{res['main_id']}.trace.json").write_text(json.dumps({"result": res, "trace": TRACE}, indent=1, default=str))
    print("[h6] RESULT " + json.dumps(res, default=str), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
