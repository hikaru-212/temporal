"""INVESTIGATION-ONLY: independent cold replay of every exported server history (sdk-rust#1766 H6)."""
import asyncio
import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from h6_e2e import MemoUpdateWorkflow  # same workflow implementation as the producer  # noqa: E402

import temporalio  # noqa: E402
from temporalio.api.enums.v1 import EventType  # noqa: E402
from temporalio.client import WorkflowHistory  # noqa: E402
from temporalio.worker import Replayer  # noqa: E402


def committed_update_wft(h: WorkflowHistory):
    ev = h.events
    for i, e in enumerate(ev):
        if e.event_type != EventType.EVENT_TYPE_WORKFLOW_TASK_COMPLETED:
            continue
        group = []
        for f in ev[i + 1:]:
            if f.event_type == EventType.EVENT_TYPE_WORKFLOW_TASK_SCHEDULED:
                break
            group.append(f)
        names = [EventType.Name(f.event_type).removeprefix("EVENT_TYPE_") for f in group]
        if any("UPDATE_ACCEPTED" in n for n in names):
            detail = []
            for f in group:
                n = EventType.Name(f.event_type).removeprefix("EVENT_TYPE_")
                if f.HasField("workflow_properties_modified_event_attributes"):
                    n += f"(wftCompleted={f.workflow_properties_modified_event_attributes.workflow_task_completed_event_id})"
                if f.HasField("workflow_execution_update_accepted_event_attributes"):
                    n += f"(seq={f.workflow_execution_update_accepted_event_attributes.accepted_request_sequencing_event_id})"
                detail.append(f"{f.event_id}:{n}")
            return e.event_id, detail
    return None, []


async def main() -> None:
    rows = []
    for p in sorted(Path(sys.argv[1]).glob("*.history.json")):
        raw = p.read_bytes()
        h = WorkflowHistory.from_json(p.stem, raw.decode())
        wft, detail = committed_update_wft(h)
        memo_first = bool(detail) and "WORKFLOW_PROPERTIES_MODIFIED" in detail[0]
        r = await Replayer(workflows=[MemoUpdateWorkflow]).replay_workflow(h, raise_on_replay_failure=False)
        f = str(r.replay_failure) if r.replay_failure else None
        rows.append({"file": p.name, "sha256": hashlib.sha256(raw).hexdigest()[:16], "events": len(h.events),
                     "update_wft_completed": wft, "memo_first": memo_first, "committed": detail,
                     "replay": ("TMPRL1100 " + f.split("Nondeterminism error: ")[1].split('"')[0]) if f and "TMPRL1100" in f else (f or "PASS")})
    for row in rows:
        print(json.dumps(row))
    mf = [r for r in rows if r["memo_first"]]
    uf = [r for r in rows if not r["memo_first"] and r["committed"]]
    print(json.dumps({"replayer_temporalio": temporalio.__version__, "histories": len(rows),
                      "memo_first": len(mf), "memo_first_TMPRL1100": sum(r["replay"].startswith("TMPRL1100") for r in mf),
                      "update_first": len(uf), "update_first_PASS": sum(r["replay"] == "PASS" for r in uf)}))


asyncio.run(main())
