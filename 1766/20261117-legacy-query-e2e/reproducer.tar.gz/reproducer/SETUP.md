# Replaying and reproducing the preserved Stage 7B scenario

`h6_e2e.py` and `replay_all.py` are the original executed files, unchanged and covered by `SHA256SUMS` and the original manifest. This file and the fully pinned dependency lists were written during packaging. The two original SDK-only hashed requirement files and original CLI release checksums are preserved in `provenance/`.

## Environment

Recorded host: Linux aarch64, CPython 3.12.3. The 1.34.0 wheel has tags `cp310-abi3-manylinux_2_17_aarch64` / `manylinux2014_aarch64`; the 1.36.1 wheel has tags `cp311-abi3-manylinux_2_17_aarch64` / `manylinux2014_aarch64`. Original wheel/bridge hashes are in `../evidence/MANIFEST_7B.txt`. The ABI tags do not mean that the recorded interpreter was Python 3.10/3.11.

Use a new working directory, extract both archives there, and run the following from that directory (the parent of `reproducer` and `evidence`). Python 3.12 and `venv` support must already be installed:

```bash
python3.12 -m venv .venv134
.venv134/bin/python -m pip install -r reproducer/requirements-1.34.0.txt
python3.12 -m venv .venv1361
.venv1361/bin/python -m pip install -r reproducer/requirements-1.36.1.txt
.venv134/bin/python -c 'import temporalio; print(temporalio.__version__)'
.venv1361/bin/python -c 'import temporalio; print(temporalio.__version__)'
```

These requirements include the exact dependencies recorded in the original manifest and remeasured during packaging. Installation needs access to PyPI and was not repeated during packaging. Other architectures get different wheel bytes and bridge hashes; they have not been tested by this package. The original SDK-only requirement files are provenance, not complete `--require-hashes` lockfiles for transitive dependencies.

## Cold replay: no Server required

```bash
timeout 60 .venv134/bin/python -B -u reproducer/replay_all.py evidence/e2e
timeout 60 .venv1361/bin/python -B -u reproducer/replay_all.py evidence/e2e
```

For each command, expect two memo-first `TMPRL1100` rows, two `PASS` rows, and a final summary with `histories=4`, `memo_first=2`, `memo_first_TMPRL1100=2`, `update_first=2`, `update_first_PASS=2`. Expected nondeterminism is the reproduced bug, not a packaging failure. The unchanged script exits 0 even when failures are found; it also permits zero input files. Validate the rows and counts, not just the exit status. GNU `timeout` is used to bound a stalled runtime; macOS may require `gtimeout` or an equivalent external limit.

The packaging recheck used the surviving original venvs, not newly installed ones. Sandboxed attempts stalled; unrestricted local runs completed. This does not mean replay needs a remote Server or establish the cause of the sandbox stall.

## Temporal CLI 1.5.1 / Server 1.29.1

Download the pinned release for the recorded Linux ARM64 host into a fresh directory:

```bash
mkdir cli151
curl -fL https://github.com/temporalio/cli/releases/download/v1.5.1/temporal_cli_1.5.1_linux_arm64.tar.gz -o cli151/temporal_cli_1.5.1_linux_arm64.tar.gz
(cd cli151 && printf '%s\n' 'bd1b0db9f18b051026de8bf6cc1505f2510f14bbb7a8b9a4a91fff46c77454f5  temporal_cli_1.5.1_linux_arm64.tar.gz' | sha256sum -c -)
tar -xzf cli151/temporal_cli_1.5.1_linux_arm64.tar.gz -C cli151
cli151/temporal --version
```

Expected version: CLI 1.5.1, Server 1.29.1, UI 2.42.1. The retained binary hash is `ce6a514a5e609dc8f6f0fe276d414fe2eea46430e28f4e23f0026f11e7de4d09`. For another OS/architecture, choose its v1.5.1 asset and corresponding hash from `provenance/original-cli-release-checksums.txt`; that portability path is unverified.

In terminal A, from the same working directory, launch the S3-equivalent in-memory headless dev Server:

```bash
cli151/temporal server start-dev --ip 127.0.0.1 --port 17433 --http-port 17434 --metrics-port 17435 --headless \
  --dynamic-config-value matching.numTaskqueueReadPartitions=1 \
  --dynamic-config-value matching.numTaskqueueWritePartitions=1
```

Wait for the startup banner to show Server 1.29.1 on port 17433. These flags are supported by the retained CLI; the command is reconstructed from the original manifest, not a preserved shell transcript. No `system.enableStickyQuery=false` override belongs to S3; that override was used by S1, which produced the separate `C3_no_query` case and incomplete C1 attempts.

## Run one controlled live case

In terminal B, from the same working directory:

```bash
mkdir live134
timeout 180 .venv134/bin/python -B -u reproducer/h6_e2e.py --addr 127.0.0.1:17433 --case S_query --out live134 --cache 1000 --sticky-timeout 60 > live134/run.log 2>&1
```

For SDK 1.36.1, use a new output directory and the other environment:

```bash
mkdir live1361
timeout 180 .venv1361/bin/python -B -u reproducer/h6_e2e.py --addr 127.0.0.1:17433 --case S_query --out live1361 --cache 1000 --sticky-timeout 60 > live1361/run.log 2>&1
```

The harness uses random IDs, starts its own signal target on a queue with no target worker, exports the main workflow's history, terminates its two workflows, and cold-replays the export. It writes `S_query-<tag>.history.json` and `S_query-h6-S_query-<tag>.trace.json`. Its main coroutine has a 120-second limit; the outer 180-second timeout bounds cleanup too. A failed run may leave test workflows on the in-memory Server. Inspect `[h6] RESULT`, `committed_wfts`, `cold_replay`, and the actual trace; a zero process exit status alone does not establish the desired ordering.

Either Query or WFT may win Matching's race. The memo-first path emits `modify_workflow_properties`, answers `legacy_query`, then emits Update accept/complete; Server event 10 is the memo and cold replay fails. The WFT-first path emits Update accept/complete then memo in one activation and replays cleanly. A passing run is a valid control, not proof the race cannot occur. Use a fresh output directory if deliberately retrying; there is no guarantee of a memo-first result on the first run. This package does not automate another 42-case campaign.

For a no-query control, use `--case S_noquery` with `--cache 1000`. For the archived uncached control configuration, use `--case S_query --cache 0` (the archive's uncached run filenames do not imply a separate `S_query_uncached` case argument). Always use a fresh output directory. The original script accepts arbitrary `--case` strings without validating them; use only these documented values.

The slot gate, initial WFT hold, and tracing wrapper are deliberate harness controls. The workflow itself has no ordering instrumentation. The resulting histories are real Server exports, but this setup does not establish uninstrumented production occurrence. Stop the dev Server with Ctrl-C after inspection; in-memory state is lost, so retain all exported files first.
