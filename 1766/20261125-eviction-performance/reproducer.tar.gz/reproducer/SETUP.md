# Reproducing the #1835 eviction-performance benchmark

This reproducer rebuilds the three measured versions from pinned commits, adds one test-only
benchmark module, and reruns the original measurement matrix. It never checks out, commits to,
or deletes anything in your `sdk-rust` clone. All output goes to `$WORK`, which defaults to
`./work` next to this file.

## Pinned sources

| Label | Commit | Role |
|---|---|---|
| U | `6eaaeebaa5d90e573e7bed5152c9b5dfca75dc08` | upstream `main` at the time (ancestor of current `main`) |
| A | `31a1a905c26034957f3968015de45177849a2b3f` | conditional eviction (first commit of PR #1835) |
| B | `9a59ba3c33ac0d64035a197dc1ae103aa670a8a5` | conservative eviction (PR #1835 head when measured) |

Do not substitute branch names. If the PR branch moves, fetch the commits by SHA.

## Requirements

- **OS.** Linux, because the probes read `/proc/self/task/*/schedstat`, `/proc/self/status` and
  `/proc/self/clear_refs`. `taskset` (util-linux) is optional.
- **Tools.** `git`, `bash`, `tar`, coreutils, and Python ≥ 3.9 (standard library only).
- **Rust.** Rust 1.100.0. The exported tree's `rust-toolchain.toml` pins channel `1.100`, so
  `rustup` will fetch it. The original run used rustc 1.100.0 (`0ef1bc386`, LLVM 23.1.5) on
  `aarch64-unknown-linux-gnu`.
- **Crates.** Network access to crates.io for the first build, or a warm Cargo cache with
  `OFFLINE=1`. `Cargo.lock` is used as committed (`--locked`).
- **Resources** (original run, 6 vCPU / 7.7 GiB VM):

  | Resource | Original run |
  |---|---|
  | Disk | 1.9 GiB release target, 3 × ~37 MiB binaries, 13 MiB tree |
  | RAM | fine with `-j 4` |
  | Build time | A 2 m 53 s (all dependencies, warm crate cache); B 1 m 16 s; U 1 m 18 s |
  | Measurement time | 36 s correctness pass, 10 m 18 s timed matrix |

## Steps

```bash
git clone https://github.com/temporalio/sdk-rust.git sdk-rust
git -C sdk-rust fetch origin pull/1835/head
# If pull/1835/head no longer contains the pinned commits, fetch them directly by SHA:
#   git -C sdk-rust fetch origin 31a1a905c26034957f3968015de45177849a2b3f 9a59ba3c33ac0d64035a197dc1ae103aa670a8a5
export SDK_RUST_REPO=$PWD/sdk-rust

cd reproducer
scripts/build_all.sh          # export A, B, U in turn; install the module; check identity; build
scripts/run_all.sh            # correctness pass (verify.jsonl), then timed matrix (timed.jsonl)

python3 scripts/analyze.py      work/raw/timed.jsonl   # per-cell tables and B/U-vs-A comparisons
python3 scripts/scaling.py      work/raw/timed.jsonl   # S2 scaling fit
python3 scripts/verify_summary.py work/raw/verify.jsonl
python3 scripts/summarize.py    work/raw/timed.jsonl work/raw/verify.jsonl > work/summary.json
```

Optional settings (see `scripts/common.sh`):

| Variable | Meaning | Original run |
|---|---|---|
| `WORK` | output directory | — |
| `CPU_LIST` | `taskset -c` list; empty disables pinning | `1-4` |
| `CARGO_JOBS` | parallel compile jobs | `4` |
| `MIN_FREE_GIB` | kill the build if free disk drops below this | 25.3 |
| `OFFLINE=1` | build without network | offline |

## What the scripts do

- **`prepare_tree.sh <label>`**
  - Runs `git archive <commit> | tar -x -m -C $WORK/tree`. `-m` forces fresh mtimes so Cargo
    rebuilds after each switch.
  - Copies `bench/perf_bench_1766.rs` to `crates/sdk-core/src/core_tests/` and appends
    `mod perf_bench_1766;` to `core_tests/mod.rs`. No other file is changed.
  - Writes `work/raw/identity_<label>.txt`.
- **Expected identity results.**
  - For A and B: exactly one differing file (`core_tests/mod.rs`) and one extra file
    (`perf_bench_1766.rs`).
  - For U: the same, plus `core_tests/legacy_query_replay.rs` and
    `changelog/fixed/eavesdropping-crystal-ball.md` left over from B. U's `mod.rs` does not
    declare the leftover module, so it is not compiled.
  - Production-diff sha256 against U:

    | Label | Production-diff sha256 |
    |---|---|
    | U | `e3b0c442…` (empty) |
    | A | `3a96b62d…` |
    | B | `35f5f0c7ef1d86e1…` |

  - Benchmark module sha256: `b610cefa509996aa7752ee2059d26b17d06c74fd3c6f4ded027e5fb6c60d8055`.
- **`build.sh <label>`**
  - Runs `cargo test -p temporalio-sdk-core --lib --release --locked --no-run -j 4` with
    `CARGO_TARGET_DIR=$WORK/target`.
  - The resulting profile, as reported by Cargo:

    | Setting | Value |
    |---|---|
    | `opt_level` | 3 |
    | `debuginfo` | 0 |
    | `debug_assertions` | false |
    | `overflow_checks` | false |
    | LTO | none |

  - Features: `default, envconfig, ephemeral-server, prometheus, tls-ring`. `ephemeral-server`
    comes from workspace feature unification. `disable_workflow_task_chunking` is **not**
    enabled, so this is the default (chunked) mode.
  - No `RUSTFLAGS` and no `[profile.release]` overrides.
  - Builds A, then B, then U in one target directory, so all three share every dependency
    artifact.
- **`run_matrix.sh` and `run_all.sh`**
  - Each invocation is a new process running only
    `core_tests::perf_bench_1766::perf_bench_1766`, with warm-up and sample counts set through
    `B1766_*` environment variables.
  - Versions alternate each round, and their order reverses on odd rounds.
  - `run_all.sh` refuses to append to existing result files.

Your absolute numbers will differ with hardware. The original evidence is in `evidence.tar.gz`.
The A/B differences and their scaling with workflow-task count are the comparable quantities.
