#!/usr/bin/env bash
# Usage: check_identity.sh <U|A|B>
# Lists every file of $WORK/tree whose git blob hash differs from the pinned commit, every extra
# file, and the sha256 of the production diff against upstream. Expected for A and B: only
# core_tests/mod.rs differs and only perf_bench_1766.rs is extra. Production diff sha256:
#   U e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 (empty)
#   A 3a96b62d173cbcd4529c3fbc575805ddcb986c7238dfd55927771ffa3e2e76be
#   B 35f5f0c7ef1d86e16d6693be53a1381d545029970fc36d7c4b930b5b6666cf25
source "$(dirname "$0")/common.sh"
L=$1; C=${COMMIT[$L]:?unknown label $L}
tmp=$(mktemp -d)
cd "$TREE"
git -C "$SDK_RUST_REPO" ls-tree -r "$C" | awk '$2=="blob"{print $3"\t"$4}' | sort -k2 > "$tmp/commit"
cut -f2 "$tmp/commit" | while IFS= read -r p; do
  if [ -e "$p" ]; then printf '%s\t%s\n' "$(git hash-object --no-filters -- "$p")" "$p"; else printf 'MISSING\t%s\n' "$p"; fi
done | sort -k2 > "$tmp/tree"
echo "commit $C"
echo "-- files differing from commit:"; join -t$'\t' -1 2 -2 2 "$tmp/commit" "$tmp/tree" | awk -F'\t' '$2!=$3{print "  "$1}'
echo "-- files in tree not in commit:"
find . -type f | sed 's|^\./||' | sort > "$tmp/files_tree"; cut -f2 "$tmp/commit" | sort > "$tmp/files_commit"
comm -23 "$tmp/files_tree" "$tmp/files_commit" | sed 's/^/  /'
echo "-- production diff vs upstream (sha256 of git diff over sdk-core/src/worker):"
git -C "$SDK_RUST_REPO" diff "$UPSTREAM" "$C" -- "${PROD_FILES[@]}" | sha256sum
echo "-- sha256 of tree production files:"; sha256sum "${PROD_FILES[@]}"
echo "-- bench module sha256:"; sha256sum crates/sdk-core/src/core_tests/perf_bench_1766.rs
rm -f "$tmp"/commit "$tmp"/tree "$tmp"/files_tree "$tmp"/files_commit; rmdir "$tmp"
