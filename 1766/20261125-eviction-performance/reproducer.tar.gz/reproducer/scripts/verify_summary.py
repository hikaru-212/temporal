#!/usr/bin/env python3
"""Correctness-control summary of verify.jsonl (one row per label/scenario/cycles/la_delay)."""
import json, sys
from collections import defaultdict
g = defaultdict(list)
for l in open(sys.argv[1]):
    r = json.loads(l)
    g[(r["scenario"], r["cycles"], r.get("la_delay_ms", 0), r["label"])].append(r)
def s(rs, f):
    vals = sorted({str(r[f]) for r in rs})
    return "/".join(vals)
print("| scenario | cycles | LA delay ms | label | n | hist events | WFT completions | WFT failures | query responses (expected) | evictions (window) | progress commits | first cmds ok | real WFT commands | cold replay | LA executions |")
print("|---|---:|---:|---|---:|---:|---|---|---|---|---|---|---|---|---|")
for k in sorted(g):
    rs = g[k]
    print(f"| {k[0]} | {k[1]} | {k[2]} | {k[3]} | {len(rs)} | {s(rs,'hist_events')} | {s(rs,'completions')} | {s(rs,'failures')} | "
          f"{s(rs,'query_responses')} ({s(rs,'expected_queries')}) | {s(rs,'win_evicts')} | {s(rs,'progress_commits')} | "
          f"{s(rs,'first_cmds_ok')} | {s(rs,'real_cmds')} | {s(rs,'replay')} | {s(rs,'la_executions')} |")
