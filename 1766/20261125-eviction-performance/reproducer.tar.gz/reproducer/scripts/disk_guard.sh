#!/usr/bin/env bash
# Usage: disk_guard.sh <pgid> <dir> <min_free_gib>; kills the process group when free space on the
# filesystem holding <dir> falls below the limit.
set -u
limit=$(awk -v g="$3" 'BEGIN{printf "%d", g*1073741824}')
while kill -0 -- "-$1" 2>/dev/null; do
  avail=$(df -B1 --output=avail "$2" | tail -1)
  if [ "$avail" -lt "$limit" ]; then
    echo "$(date -Is) DISK GUARD: avail=$avail bytes < $3 GiB, killing pgid $1" >&2
    kill -TERM -- "-$1"; sleep 2; kill -KILL -- "-$1" 2>/dev/null; exit 1
  fi
  sleep 2
done
