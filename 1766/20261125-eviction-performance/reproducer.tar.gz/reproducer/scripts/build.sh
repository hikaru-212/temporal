#!/usr/bin/env bash
# Usage: build.sh <U|A|B>
# Builds the sdk-core lib-test binary of the current $WORK/tree with the release profile and copies
# it to $WORK/bins/<label>/. Same command as the original run, minus --offline (set OFFLINE=1 to
# add it back when the crates are already in the local Cargo cache).
source "$(dirname "$0")/common.sh"
L=$1
offline=(); [ "${OFFLINE:-0}" = 1 ] && offline=(--offline)
log=$RAW/build_$L.json
echo "start $(date -Is) avail=$(df -B1 --output=avail "$WORK" | tail -1)"
cd "$TREE"
setsid env CARGO_TARGET_DIR="$TARGET" cargo test -p temporalio-sdk-core --lib --release --locked \
  "${offline[@]}" --no-run -j "$CARGO_JOBS" --message-format=json-render-diagnostics > "$log" &
pid=$!
if awk -v g="$MIN_FREE_GIB" 'BEGIN{exit !(g>0)}'; then sleep 1; "$ROOT/scripts/disk_guard.sh" "$pid" "$WORK" "$MIN_FREE_GIB" & fi
wait "$pid"; rc=$?
echo "cargo rc=$rc end $(date -Is) avail=$(df -B1 --output=avail "$WORK" | tail -1)"
exe=$(grep -o '"executable":"[^"]*temporalio_sdk_core-[0-9a-f]*"' "$log" | tail -1 | sed 's/"executable":"//;s/"$//')
echo "exe=$exe"
if [ "$rc" -eq 0 ] && [ -n "$exe" ]; then
  mkdir -p "$BINS/$L"; cp "$exe" "$BINS/$L/sdk_core_lib_tests"; sha256sum "$BINS/$L/sdk_core_lib_tests"
fi
exit "$rc"
