#!/usr/bin/env python3
"""S2 scaling fit, end-to-end totals and the hypothetical-rate sensitivity table."""
import json, statistics as st, sys, math
from collections import defaultdict
rows = [json.loads(l) for l in open(sys.argv[1])]
g = defaultdict(list)
for r in rows:
    if not r["warmup"] and not r["verify"]:
        g[(r["scenario"], r["cycles"], r.get("la_delay_ms", 0), r["label"])].append(r)
def med(k, f): return st.median([r[f] for r in g[k]])
print("## S2 scaling (B - A, medians)")
print("| cycles | events | WFTs | hist bytes | A µs | B µs | Δ µs | Δ/WFT µs | Δ/event µs | ΔCPU µs | ΔCPU/WFT µs | B win acts | A e2e ms | B e2e ms | e2e Δ ms |")
print("|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
pts = []
for k in [0, 18, 198, 998, 1998]:
    a, b = ("s2", k, 0, "A"), ("s2", k, 0, "B")
    ev, w = g[a][0]["hist_events"], g[a][0]["wft_count"]
    hb = st.median([r["hist_bytes"] for r in g[a]])
    d = med(b, "lat_ns") - med(a, "lat_ns"); dc = med(b, "cpu_ns") - med(a, "cpu_ns")
    pts.append((w, ev, d, dc))
    print(f"| {k} | {ev} | {w} | {hb:.0f} | {med(a,'lat_ns')/1e3:.1f} | {med(b,'lat_ns')/1e3:.1f} | {d/1e3:.1f} | {d/1e3/w:.1f} | {d/1e3/ev:.2f} | {dc/1e3:.1f} | {dc/1e3/w:.1f} | {st.median([r['win_acts'] for r in g[b]]):.0f} | {med(a,'e2e_ns')/1e6:.2f} | {med(b,'e2e_ns')/1e6:.2f} | {(med(b,'e2e_ns')-med(a,'e2e_ns'))/1e6:.2f} |")
def ols(xs, ys):
    mx, my = st.mean(xs), st.mean(ys)
    s = sum((x-mx)*(y-my) for x, y in zip(xs, ys)) / sum((x-mx)**2 for x in xs)
    return s, my - s*mx
s, c = ols([p[0] for p in pts], [p[2] for p in pts])
print(f"\nOLS latency Δ ≈ {s/1e3:.1f} µs × WFTs + {c/1e3:.1f} µs (5 points)")
s2, c2 = ols([p[0] for p in pts], [p[3] for p in pts])
print(f"OLS CPU Δ ≈ {s2/1e3:.1f} µs × WFTs + {c2/1e3:.1f} µs")
big = [p for p in pts if p[0] >= 20]
ll, _ = ols([math.log(p[0]) for p in big], [math.log(p[2]) for p in big])
print(f"log-log slope of latency Δ vs WFTs (20..2000 WFTs): {ll:.3f}")
for i in range(1, len(pts)):
    (w0, _, d0, _), (w1, _, d1, _) = pts[i-1], pts[i]
    print(f"  marginal {w0}->{w1} WFTs: {(d1-d0)/(w1-w0)/1e3:.1f} µs/WFT")
print("\n## Sensitivity (hypothetical share p of real WFTs that hit a B-only eviction; mean added latency per WFT)")
print("| p | " + " | ".join(f"{p[1]} events" for p in pts if p[0] >= 20) + " |")
print("|---|" + "---:|" * len([p for p in pts if p[0] >= 20]))
for p in [0.0001, 0.001, 0.01, 0.05, 0.10]:
    print(f"| {p*100:g}% | " + " | ".join(f"{p*q[2]/1e3:.2f} µs" if p*q[2] < 1e6 else f"{p*q[2]/1e6:.2f} ms" for q in pts if q[0] >= 20) + " |")
