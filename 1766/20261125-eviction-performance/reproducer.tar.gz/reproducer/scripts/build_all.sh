#!/usr/bin/env bash
# Builds A, then B, then U, in the same order as the original run.
source "$(dirname "$0")/common.sh"
for L in A B U; do
  "$ROOT/scripts/prepare_tree.sh" "$L"
  "$ROOT/scripts/build.sh" "$L" 2>&1 | tee "$RAW/build_$L.log"
done
