#!/usr/bin/env bash
# The full matrix of the original run: correctness pass first, then the timed matrix.
# Original wall time on 6 vCPU: ~36 s verify, ~10.5 min timed.
source "$(dirname "$0")/common.sh"
M=$ROOT/scripts/run_matrix.sh
V=$RAW/verify.jsonl; T=$RAW/timed.jsonl
for f in "$V" "$T"; do [ -e "$f" ] && { echo "$f exists; move it away first (runs append)" >&2; exit 1; }; done
echo "verify start $(date -Is)"
for K in 0 18 198 998 1998; do $M $V s2 $K 1 3 0 1 A B U; done
for sc in s0 s1; do for K in 18 198 998 1998; do $M $V $sc $K 1 3 0 1 A B U; done; done
for sc in s3sig s3upd; do for K in 18 198 998; do $M $V $sc $K 1 3 0 1 A B U; done; done
$M $V s4 0 1 3 0 1 A B U
LA_DELAY_MS=20 $M $V s4 0 1 3 0 1 A B U
echo "timed start $(date -Is)"
for K in 0 18 198 998 1998; do $M $T s2 $K 10 10 3 0 A B U; done
for sc in s0 s1; do for K in 18 198 998 1998; do $M $T $sc $K 6 10 3 0 A B U; done; done
for sc in s3sig s3upd; do for K in 18 198 998; do $M $T $sc $K 6 10 3 0 A B U; done; done
$M $T s4 0 10 10 3 0 A B U
LA_DELAY_MS=20 $M $T s4 0 6 5 2 0 A B U
echo "done $(date -Is)"
