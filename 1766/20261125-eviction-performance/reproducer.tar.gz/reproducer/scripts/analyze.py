#!/usr/bin/env python3
"""Summarise #1766 benchmark JSONL. Pure standard library (no numpy available on this VM).

Usage: analyze.py <timed.jsonl> [<timed2.jsonl> ...]
Prints a markdown summary per (scenario, cycles), comparing every label to A.
"""
import json
import math
import random
import statistics as st
import sys
from collections import defaultdict


def pct(xs, p):
    """Linear-interpolated percentile (same definition as numpy's default)."""
    xs = sorted(xs)
    if not xs:
        return float("nan")
    k = (len(xs) - 1) * p / 100
    f, c = math.floor(k), math.ceil(k)
    return xs[f] + (xs[c] - xs[f]) * (k - f)


def mwu_p(a, b):
    """Two-sided Mann-Whitney U, normal approximation with tie correction."""
    n1, n2 = len(a), len(b)
    allv = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    ranks = [0.0] * len(allv)
    i = 0
    ties = 0.0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1][0] == allv[i][0]:
            j += 1
        r = (i + j) / 2 + 1
        for k in range(i, j + 1):
            ranks[k] = r
        t = j - i + 1
        ties += t**3 - t
        i = j + 1
    r1 = sum(r for r, (_, g) in zip(ranks, allv) if g == 0)
    u1 = r1 - n1 * (n1 + 1) / 2
    mu = n1 * n2 / 2
    n = n1 + n2
    sigma = math.sqrt(n1 * n2 / 12 * ((n + 1) - ties / (n * (n - 1))))
    if sigma == 0:
        return 1.0
    z = (u1 - mu) / sigma
    return math.erfc(abs(z) / math.sqrt(2))


def boot_median_diff(a, b, n=2000, seed=1766):
    rnd = random.Random(seed)
    diffs = []
    for _ in range(n):
        ra = [a[rnd.randrange(len(a))] for _ in a]
        rb = [b[rnd.randrange(len(b))] for _ in b]
        diffs.append(st.median(rb) - st.median(ra))
    return pct(diffs, 2.5), pct(diffs, 97.5)


def us(ns):
    return ns / 1000.0


def main(paths):
    rows = []
    for p in paths:
        with open(p) as f:
            rows += [json.loads(l) for l in f if l.strip()]
    groups = defaultdict(lambda: defaultdict(list))
    for r in rows:
        if r["warmup"] or r["verify"]:
            continue
        groups[(r["scenario"], r["cycles"], r.get("la_delay_ms", 0))][r["label"]].append(r)
    for key in sorted(groups):
        sc, k, lad = key
        g = groups[key]
        any_r = next(iter(g.values()))[0]
        print(f"\n### {sc} cycles={k} la_delay_ms={lad} hist_events={any_r['hist_events']} "
              f"hist_bytes={any_r['hist_bytes']} wft_count={any_r['wft_count']} "
              f"partial_events={any_r['partial_events']}")
        print("| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs "
              "| win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) "
              "| hwm-rss0 median KiB | failures | real cmds |")
        print("|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|")
        for label in sorted(g):
            rs = g[label]
            lat = [r["lat_ns"] for r in rs]
            cpu = [r["cpu_ns"] for r in rs]
            ql = [r["q_lat_ns"] for r in rs if r["q_lat_ns"] >= 0]

            def dist(field):
                c = defaultdict(int)
                for r in rs:
                    c[r[field]] += 1
                return ",".join(f"{v}×{n}" for v, n in sorted(c.items()))

            mem = [r["hwm_kb"] - r["rss0_kb"] for r in rs]
            print(f"| {label} | {len(rs)} | {us(st.median(lat)):.1f} | {us(pct(lat,95)):.1f} | "
                  f"{us(pct(lat,99)):.1f} | {us(st.mean(lat)):.1f} | {us(st.median(cpu)):.1f} | "
                  f"{us(st.median(ql)) if ql else float('nan'):.1f} | {dist('win_evicts')} | "
                  f"{dist('win_acts')} | {dist('win_replay_acts')} | {dist('win_fetches')} | "
                  f"{dist('win_fetch_bytes')} | {dist('win_la_executions')} | {st.median(mem):.0f} | "
                  f"{sum(r['failures'] for r in rs)} | {dist('real_cmds')} |")
        if "A" in g:
            a = [r["lat_ns"] for r in g["A"]]
            ac = [r["cpu_ns"] for r in g["A"]]
            for label in sorted(g):
                if label == "A":
                    continue
                b = [r["lat_ns"] for r in g[label]]
                bc = [r["cpu_ns"] for r in g[label]]
                lo, hi = boot_median_diff(a, b)
                d = st.median(b) - st.median(a)
                print(f"- {label} vs A: median Δ = {us(d):+.1f} µs (95% bootstrap CI {us(lo):+.1f} … "
                      f"{us(hi):+.1f}), ratio {st.median(b)/st.median(a):.3f}, MWU p = {mwu_p(a, b):.3g}; "
                      f"CPU median Δ = {us(st.median(bc)-st.median(ac)):+.1f} µs, ratio "
                      f"{st.median(bc)/st.median(ac):.3f}")


if __name__ == "__main__":
    main(sys.argv[1:])
