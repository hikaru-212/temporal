#!/usr/bin/env python3
"""Derive the measurement summary used in results.json from timed.jsonl and verify.jsonl.

Usage: summarize.py <timed.jsonl> <verify.jsonl> > summary.json

Standard library only. Conventions (identical to analyze.py, which produced the original report):
- Warm-up rows (warmup=true) are excluded; timed rows never carry verify=true.
- Percentiles use linear interpolation between closest ranks (numpy's default definition).
- The 95% CI of the median difference (label - A) uses 2,000 bootstrap resamples with Python's
  random.Random(1766), freshly seeded for every comparison; each iteration resamples A, then the
  other label, from the rows in file order, and the interval is the 2.5/97.5 percentile.
- MWU p is two-sided, normal approximation with tie correction, no continuity correction.
- Missing la_delay_ms means 0 (only s4 rows carry it).
"""
import json
import math
import random
import statistics as st
import sys
from collections import Counter, defaultdict

BOOTSTRAP_RESAMPLES = 2000
BOOTSTRAP_SEED = 1766


def pct(xs, p):
    xs = sorted(xs)
    k = (len(xs) - 1) * p / 100
    f, c = math.floor(k), math.ceil(k)
    return xs[f] + (xs[c] - xs[f]) * (k - f)


def mwu_p(a, b):
    n1, n2 = len(a), len(b)
    allv = sorted([(v, 0) for v in a] + [(v, 1) for v in b])
    ranks = [0.0] * len(allv)
    i = 0
    ties = 0.0
    while i < len(allv):
        j = i
        while j + 1 < len(allv) and allv[j + 1][0] == allv[i][0]:
            j += 1
        for k in range(i, j + 1):
            ranks[k] = (i + j) / 2 + 1
        t = j - i + 1
        ties += t**3 - t
        i = j + 1
    r1 = sum(r for r, (_, g) in zip(ranks, allv) if g == 0)
    u1 = r1 - n1 * (n1 + 1) / 2
    n = n1 + n2
    sigma = math.sqrt(n1 * n2 / 12 * ((n + 1) - ties / (n * (n - 1))))
    if sigma == 0:
        return 1.0
    return math.erfc(abs((u1 - n1 * n2 / 2) / sigma) / math.sqrt(2))


def boot_ci(a, b):
    rnd = random.Random(BOOTSTRAP_SEED)
    diffs = []
    for _ in range(BOOTSTRAP_RESAMPLES):
        ra = [a[rnd.randrange(len(a))] for _ in a]
        rb = [b[rnd.randrange(len(b))] for _ in b]
        diffs.append(st.median(rb) - st.median(ra))
    return [pct(diffs, 2.5), pct(diffs, 97.5)]


def dist(rows, field):
    return {str(k): v for k, v in sorted(Counter(r[field] for r in rows).items(), key=lambda kv: str(kv[0]))}


def span(xs):
    return {"min": min(xs), "median": st.median(xs), "max": max(xs)}


def key(r):
    return (r["scenario"], r["cycles"], r.get("la_delay_ms", 0))


def load(path):
    with open(path) as f:
        return [json.loads(line) for line in f if line.strip()]


def summarize(timed_path, verify_path):
    timed = load(timed_path)
    verify = load(verify_path)
    groups = defaultdict(lambda: defaultdict(list))
    warm = Counter()
    for r in timed:
        if r["warmup"]:
            warm[key(r) + (r["label"],)] += 1
            continue
        groups[key(r)][r["label"]].append(r)

    vgroups = defaultdict(list)
    for r in verify:
        vgroups[key(r) + (r["label"],)].append(r)
    validity = {}
    for (sc, _k, lad, label), rs in vgroups.items():
        ok = all(r["replay"] == "ok" and r["failures"] == 0 for r in rs)
        prev = validity.get((sc, lad, label), True)
        validity[(sc, lad, label)] = prev and ok

    cells, comparisons = [], []
    for k in sorted(groups):
        sc, cyc, lad = k
        for label in sorted(groups[k]):
            rs = groups[k][label]
            lat = [r["lat_ns"] for r in rs]
            cpu = [r["cpu_ns"] for r in rs]
            ql = [r["q_lat_ns"] for r in rs if r["q_lat_ns"] >= 0]
            cells.append({
                "scenario": sc, "cycles": cyc, "la_delay_ms": lad, "label": label,
                "n": len(rs), "warmup_rows_excluded": warm[k + (label,)],
                "rounds": sorted({r["round"] for r in rs}),
                "hist_events": sorted({r["hist_events"] for r in rs}),
                "hist_bytes": span([r["hist_bytes"] for r in rs]),
                "wft_count": sorted({r["wft_count"] for r in rs}),
                "partial_events": sorted({r["partial_events"] for r in rs}),
                "latency_ns": {"median": st.median(lat), "mean": st.mean(lat), "p95": pct(lat, 95),
                               "p99": pct(lat, 99), "min": min(lat), "max": max(lat)},
                "cpu_ns": {"median": st.median(cpu), "p95": pct(cpu, 95)},
                "query_latency_ns_median": st.median(ql) if ql else None,
                "e2e_ns_median": st.median([r["e2e_ns"] for r in rs]),
                "window": {
                    "evictions": dist(rs, "win_evicts"),
                    "activations": dist(rs, "win_acts"),
                    "replay_activations": dist(rs, "win_replay_acts"),
                    "history_fetches": dist(rs, "win_fetches"),
                    "history_fetch_bytes": span([r["win_fetch_bytes"] for r in rs]),
                    "la_executions": dist(rs, "win_la_executions"),
                },
                "la_executions_total": dist(rs, "la_executions"),
                "history_fetches_total": dist(rs, "total_fetches"),
                "wft_completions": dist(rs, "completions"),
                "wft_failures_total": sum(r["failures"] for r in rs),
                "query_responses": dist(rs, "query_responses"),
                "expected_queries": sorted({r["expected_queries"] for r in rs}),
                "progress_commits": dist(rs, "progress_commits"),
                "first_completion_as_expected": all(r["first_cmds_ok"] for r in rs),
                "next_wft_commands": dist(rs, "real_cmds"),
                "rss_growth_kib_median": st.median([r["hwm_kb"] - r["rss0_kb"] for r in rs]),
                "correctness": "valid" if validity.get((sc, lad, label), False) else "correctness_invalid",
            })
        if "A" in groups[k]:
            a = [r["lat_ns"] for r in groups[k]["A"]]
            ac = [r["cpu_ns"] for r in groups[k]["A"]]
            for label in sorted(groups[k]):
                if label == "A":
                    continue
                b = [r["lat_ns"] for r in groups[k][label]]
                bc = [r["cpu_ns"] for r in groups[k][label]]
                comparisons.append({
                    "scenario": sc, "cycles": cyc, "la_delay_ms": lad, "label": label, "baseline": "A",
                    "median_delta_ns": st.median(b) - st.median(a),
                    "median_delta_ci95_ns": boot_ci(a, b),
                    "median_ratio": st.median(b) / st.median(a),
                    "mwu_p": mwu_p(a, b),
                    "cpu_median_delta_ns": st.median(bc) - st.median(ac),
                    "cpu_median_ratio": st.median(bc) / st.median(ac),
                    "comparison_valid": validity.get((sc, lad, label), False)
                    and validity.get((sc, lad, "A"), False),
                })

    pts = []
    for cyc in sorted({k[1] for k in groups if k[0] == "s2"}):
        a, b = groups[("s2", cyc, 0)]["A"], groups[("s2", cyc, 0)]["B"]
        pts.append({
            "cycles": cyc, "hist_events": a[0]["hist_events"], "wft_count": a[0]["wft_count"],
            "latency_delta_ns": st.median([r["lat_ns"] for r in b]) - st.median([r["lat_ns"] for r in a]),
            "cpu_delta_ns": st.median([r["cpu_ns"] for r in b]) - st.median([r["cpu_ns"] for r in a]),
            "e2e_delta_ns": st.median([r["e2e_ns"] for r in b]) - st.median([r["e2e_ns"] for r in a]),
        })

    def ols(xs, ys):
        mx, my = st.mean(xs), st.mean(ys)
        s = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
        return {"slope_ns_per_wft": s, "intercept_ns": my - s * mx}

    w = [p["wft_count"] for p in pts]
    big = [p for p in pts if p["wft_count"] >= 20]
    scaling = {
        "method": "Ordinary least squares over the five S2 points (B median - A median) versus the "
                  "workflow-task count of the history; log-log slope over the points with >= 20 WFTs; "
                  "marginal slope between adjacent points. Describes this timer-cycle workload "
                  "(5 events per WFT) over 2-2,000 WFTs only.",
        "points": pts,
        "latency_fit": ols(w, [p["latency_delta_ns"] for p in pts]),
        "cpu_fit": ols(w, [p["cpu_delta_ns"] for p in pts]),
        "loglog_slope_wft_ge_20": ols([math.log(p["wft_count"]) for p in big],
                                      [math.log(p["latency_delta_ns"]) for p in big])["slope_ns_per_wft"],
        "marginal_latency_ns_per_wft": [
            {"from_wft": p0["wft_count"], "to_wft": p1["wft_count"],
             "ns_per_wft": (p1["latency_delta_ns"] - p0["latency_delta_ns"]) / (p1["wft_count"] - p0["wft_count"])}
            for p0, p1 in zip(pts, pts[1:])],
    }

    vcells = []
    for k in sorted(vgroups):
        rs = vgroups[k]
        vcells.append({
            "scenario": k[0], "cycles": k[1], "la_delay_ms": k[2], "label": k[3], "n": len(rs),
            "hist_events": sorted({r["hist_events"] for r in rs}),
            "wft_completions": dist(rs, "completions"),
            "wft_failures_total": sum(r["failures"] for r in rs),
            "query_responses": dist(rs, "query_responses"),
            "expected_queries": sorted({r["expected_queries"] for r in rs}),
            "window_evictions": dist(rs, "win_evicts"),
            "progress_commits": dist(rs, "progress_commits"),
            "first_completion_as_expected": all(r["first_cmds_ok"] for r in rs),
            "next_wft_commands": dist(rs, "real_cmds"),
            "cold_replay": dist(rs, "replay"),
            "la_executions_total": dist(rs, "la_executions"),
        })

    return {
        "timed_rows": len(timed),
        "timed_rows_excluding_warmup": sum(not r["warmup"] for r in timed),
        "verify_rows": len(verify),
        "statistics": {
            "percentile": "linear interpolation between closest ranks",
            "ci": f"bootstrap of median difference, {BOOTSTRAP_RESAMPLES} resamples, "
                  f"random.Random({BOOTSTRAP_SEED}) reseeded per comparison, resample A then label, 2.5/97.5 percentiles",
            "test": "two-sided Mann-Whitney U, normal approximation with tie correction",
        },
        "timed_cells": cells,
        "comparisons": comparisons,
        "s2_scaling": scaling,
        "verify_cells": vcells,
    }


if __name__ == "__main__":
    json.dump(summarize(sys.argv[1], sys.argv[2]), sys.stdout, indent=1)
    print()
