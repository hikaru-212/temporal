#!/usr/bin/env bash
# The only change made to each exported tree: copy the benchmark module in and declare it.
source "$(dirname "$0")/common.sh"
T=$TREE/crates/sdk-core/src/core_tests
cp "$ROOT/bench/perf_bench_1766.rs" "$T/perf_bench_1766.rs"
grep -qx 'mod perf_bench_1766;' "$T/mod.rs" || echo 'mod perf_bench_1766;' >> "$T/mod.rs"
