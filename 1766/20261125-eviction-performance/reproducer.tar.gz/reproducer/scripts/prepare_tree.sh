#!/usr/bin/env bash
# Usage: prepare_tree.sh <U|A|B>
# Exports the pinned commit into $WORK/tree (no checkout of SDK_RUST_REPO), adds the benchmark
# module and checks the tree's identity. The tree is reused across versions on purpose: Cargo then
# recompiles only the workspace crates, and the three binaries share one dependency build.
# `tar -m` stamps extracted files with the current time; without it Cargo can see a newer
# version's sources as older than the previous build and silently reuse a stale binary.
# Switching to U leaves A/B-only files (legacy_query_replay.rs, a changelog fragment) in the tree;
# U's core_tests/mod.rs does not declare that module, so it is not compiled.
source "$(dirname "$0")/common.sh"
L=$1; C=${COMMIT[$L]:?unknown label $L}
git -C "$SDK_RUST_REPO" cat-file -e "$C^{commit}" || { echo "commit $C missing from $SDK_RUST_REPO" >&2; exit 1; }
mkdir -p "$TREE"
git -C "$SDK_RUST_REPO" archive "$C" | tar -x -m -C "$TREE"
"$ROOT/scripts/install_bench.sh"
"$ROOT/scripts/check_identity.sh" "$L" | tee "$RAW/identity_$L.txt"
