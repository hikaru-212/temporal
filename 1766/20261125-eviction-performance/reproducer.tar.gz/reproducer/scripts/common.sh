#!/usr/bin/env bash
# Shared configuration. Every path derives from this reproducer directory or from variables the
# caller sets; nothing refers to the original investigation machine.
#   SDK_RUST_REPO  (required) a git clone of temporalio/sdk-rust containing the three commits below.
#                  It is only read (rev-parse, archive, ls-tree, diff); it is never checked out or modified.
#   WORK           scratch directory for the build tree, target dir, binaries and results
#                  (default: <reproducer>/work).
#   CPU_LIST       CPUs passed to `taskset -c` for measurements (default 1-4; empty disables pinning).
#   MIN_FREE_GIB   if > 0, the build is killed when free space on the WORK filesystem drops below it.
#   CARGO_JOBS     parallel compile jobs (default 4).
set -euo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
: "${SDK_RUST_REPO:?set SDK_RUST_REPO to a clone of temporalio/sdk-rust}"
WORK=${WORK:-$ROOT/work}
TREE=$WORK/tree
TARGET=$WORK/target
BINS=$WORK/bins
RAW=$WORK/raw
CPU_LIST=${CPU_LIST-1-4}
MIN_FREE_GIB=${MIN_FREE_GIB:-0}
CARGO_JOBS=${CARGO_JOBS:-4}
UPSTREAM=6eaaeebaa5d90e573e7bed5152c9b5dfca75dc08
declare -A COMMIT=(
  [U]=6eaaeebaa5d90e573e7bed5152c9b5dfca75dc08
  [A]=31a1a905c26034957f3968015de45177849a2b3f
  [B]=9a59ba3c33ac0d64035a197dc1ae103aa670a8a5
)
PROD_FILES=(
  crates/sdk-core/src/worker/workflow/managed_run.rs
  crates/sdk-core/src/worker/workflow/machines/workflow_machines.rs
  crates/sdk-core/src/worker/workflow/machines/workflow_machines/local_acts.rs
)
TEST_NAME=core_tests::perf_bench_1766::perf_bench_1766
mkdir -p "$WORK" "$BINS" "$RAW"
