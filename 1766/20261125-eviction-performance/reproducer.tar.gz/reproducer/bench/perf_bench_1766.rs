//! Investigation-only benchmark for temporalio/sdk-rust#1766. Not part of any upstream change.
//!
//! Compiled unchanged into the U, A and B source trees as a lib test module. It does nothing unless
//! `B1766_SCENARIO` is set, and appends one JSON object per sample to `B1766_OUT`.
//!
//! Timed window: from the moment the mocked poll stream hands the next real workflow task to Core
//! (`Probe::start`) until the mocked server receives that task's completion (`Probe::stop`). The
//! window therefore includes cache reuse or eviction, run reconstruction, history fetch from the
//! in-memory mock, replay, the synthetic lang driver below, and completion. The synthetic lang is
//! a few lines of Rust per activation and is NOT a model of a real language SDK's cost.

use crate::{
    PollError, WorkflowTaskCompletion, init_replay_worker, prost_dur,
    replay::{HistoryForReplay, ReplayWorkerInput, TestHistoryBuilder},
    test_help::{
        MocksHolder, PollWFTRespExt, ResponseType, WorkerExt, hist_to_poll_resp, mock_worker,
        query_ok, schedule_local_activity_cmd, start_timer_cmd, test_worker_cfg,
    },
    worker::{LEGACY_QUERY_ID, client::mocks::mock_worker_client},
};
use futures_util::{StreamExt, stream};
use prost::Message as _;
use std::{
    collections::HashMap,
    io::Write as _,
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};
use temporalio_common::protos::{
    coresdk::{
        ActivityTaskCompletion,
        activity_result::ActivityExecutionResult,
        common::NamespacedWorkflowExecution,
        workflow_activation::{
            WorkflowActivation, remove_from_cache::EvictionReason,
            workflow_activation_job::Variant as Job,
        },
        workflow_commands::{
            ActivityCancellationType, ModifyWorkflowProperties, SignalExternalWorkflowExecution,
            StartTimer, UpdateResponse, signal_external_workflow_execution, update_response,
            workflow_command,
        },
        workflow_completion::WorkflowActivationCompletion,
    },
    temporal::api::{
        command::v1::{Command, command::Attributes as CmdAttrs},
        common::v1::{Memo, Payload},
        enums::v1::{CommandType, EventType},
        history::v1::{
            History, MarkerRecordedEventAttributes, TimerStartedEventAttributes,
            WorkflowPropertiesModifiedEventAttributes, history_event,
        },
        protocol::v1::Message as ProtocolMessage,
        query::v1::WorkflowQuery,
        workflowservice::v1::{
            GetWorkflowExecutionHistoryResponse, PollWorkflowTaskQueueResponse,
            RespondQueryTaskCompletedResponse,
        },
    },
};
use tokio::sync::{Notify, mpsc};

const WFID: &str = "perf-1766";
const UPDATE_ID: &str = "upd";

// ---------------------------------------------------------------------------------------------
// Process-level probes (Linux /proc). CPU is the sum of on-CPU ns over all threads of the process,
// which covers the dedicated workflow-processing thread as well as the test runtime thread.
// ---------------------------------------------------------------------------------------------

fn cpu_ns() -> u64 {
    let mut total = 0;
    if let Ok(rd) = std::fs::read_dir("/proc/self/task") {
        for e in rd.flatten() {
            if let Ok(s) = std::fs::read_to_string(e.path().join("schedstat")) {
                total += s
                    .split_whitespace()
                    .next()
                    .and_then(|v| v.parse::<u64>().ok())
                    .unwrap_or(0);
            }
        }
    }
    total
}

fn status_kb(key: &str) -> i64 {
    std::fs::read_to_string("/proc/self/status")
        .ok()
        .and_then(|s| {
            s.lines()
                .find(|l| l.starts_with(key))
                .and_then(|l| l.split_whitespace().nth(1))
                .and_then(|v| v.parse().ok())
        })
        .unwrap_or(-1)
}

#[derive(Default)]
struct Probe {
    t0: Option<Instant>,
    cpu0: u64,
    rss0_kb: i64,
    t1: Option<Instant>,
    cpu1: u64,
    hwm1_kb: i64,
}

impl Probe {
    fn start(&mut self) {
        self.cpu0 = cpu_ns();
        // Resets VmHWM to the current RSS so the reading at stop is the peak inside the window.
        let _ = std::fs::write("/proc/self/clear_refs", "5");
        self.rss0_kb = status_kb("VmRSS:");
        self.t0 = Some(Instant::now());
    }
    fn stop(&mut self) {
        self.t1 = Some(Instant::now());
        self.cpu1 = cpu_ns();
        self.hwm1_kb = status_kb("VmHWM:");
    }
    fn in_window(&self, t: Instant) -> bool {
        matches!((self.t0, self.t1), (Some(a), Some(b)) if t >= a && t <= b)
    }
    fn lat_ns(&self) -> i128 {
        match (self.t0, self.t1) {
            (Some(a), Some(b)) => (b - a).as_nanos() as i128,
            _ => -1,
        }
    }
}

#[derive(Default)]
struct Obs {
    /// (when lang received it, job names, is_replaying)
    activations: Vec<(Instant, Vec<&'static str>, bool)>,
    completions: Vec<(Instant, Vec<Command>, Vec<ProtocolMessage>)>,
    wft_failures: Vec<String>,
    query_sent: Vec<Instant>,
    query_answered: Vec<Instant>,
    /// (when, bytes)
    fetches: Vec<(Instant, usize)>,
    la_executions: Vec<Instant>,
    first_yield: Option<Instant>,
    last_answer: Option<Instant>,
    probe: Probe,
}

impl Obs {
    fn server_calls(&self) -> usize {
        self.completions.len() + self.wft_failures.len() + self.query_answered.len()
    }
}

fn job_name(job: &Job) -> &'static str {
    match job {
        Job::InitializeWorkflow(_) => "Init",
        Job::ResolveSignalExternalWorkflow(_) => "ResolveSignalExternal",
        Job::DoUpdate(_) => "DoUpdate",
        Job::SignalWorkflow(_) => "Signal",
        Job::QueryWorkflow(_) => "Query",
        Job::RemoveFromCache(_) => "Evict",
        Job::FireTimer(_) => "FireTimer",
        Job::ResolveActivity(_) => "ResolveActivity",
        _ => "Other",
    }
}

fn job_names(act: &WorkflowActivation) -> Vec<&'static str> {
    act.jobs
        .iter()
        .filter_map(|j| j.variant.as_ref())
        .map(job_name)
        .collect()
}

fn signal_external() -> workflow_command::Variant {
    SignalExternalWorkflowExecution {
        seq: 1,
        target: Some(
            signal_external_workflow_execution::Target::WorkflowExecution(
                NamespacedWorkflowExecution {
                    namespace: "default".to_string(),
                    workflow_id: "signal-target".to_string(),
                    run_id: "".to_string(),
                },
            ),
        ),
        signal_name: "wake".to_string(),
        ..Default::default()
    }
    .into()
}

fn memo() -> workflow_command::Variant {
    ModifyWorkflowProperties {
        upserted_memo: Some(Memo {
            fields: HashMap::from([("progress".to_string(), Payload::default())]),
        }),
    }
    .into()
}

/// Synthetic lang for S0-S3. Runs `cycles` sequential timers, then signals another workflow and
/// upserts a memo once that signal is acknowledged. Like the Python SDK it handles signals and
/// updates before other jobs of the same activation. It never reads history length or time, so
/// both reusing the cached run and rebuilding it commit replayable history when the next task
/// brings no new work (S2).
fn bench_lang(cycles: u32, act: &WorkflowActivation) -> Vec<workflow_command::Variant> {
    let jobs: Vec<&Job> = act.jobs.iter().filter_map(|j| j.variant.as_ref()).collect();
    let mut cmds = vec![];
    for job in &jobs {
        match job {
            Job::QueryWorkflow(q) => cmds.push(query_ok(q.query_id.clone(), "answer")),
            Job::DoUpdate(u) => {
                for response in [
                    update_response::Response::Accepted(()),
                    update_response::Response::Completed(Payload::default()),
                ] {
                    cmds.push(
                        UpdateResponse {
                            protocol_instance_id: u.protocol_instance_id.clone(),
                            response: Some(response),
                        }
                        .into(),
                    );
                }
            }
            Job::SignalWorkflow(_) => cmds.push(
                StartTimer {
                    seq: cycles + 1,
                    start_to_fire_timeout: Some(prost_dur!(from_secs(60))),
                }
                .into(),
            ),
            _ => {}
        }
    }
    for job in &jobs {
        match job {
            Job::InitializeWorkflow(_) => cmds.push(if cycles > 0 {
                start_timer_cmd(1, Duration::from_secs(1))
            } else {
                signal_external()
            }),
            Job::FireTimer(ft) if ft.seq < cycles => {
                cmds.push(start_timer_cmd(ft.seq + 1, Duration::from_secs(1)))
            }
            Job::FireTimer(ft) if ft.seq == cycles => cmds.push(signal_external()),
            Job::ResolveSignalExternalWorkflow(_) => cmds.push(memo()),
            _ => {}
        }
    }
    cmds
}

#[derive(Clone, Copy, PartialEq, Debug)]
enum Scenario {
    /// No legacy query.
    S0,
    /// One legacy query before the acknowledgement: preparing it runs no workflow code.
    S1,
    /// One legacy query after the acknowledgement; the next task adds only its own started event.
    S2,
    /// As S2, but the next task carries a new signal event.
    S3Signal,
    /// As S2, but the next task carries an update request.
    S3Update,
}

impl Scenario {
    fn parse(s: &str) -> Self {
        match s {
            "s0" => Self::S0,
            "s1" => Self::S1,
            "s2" => Self::S2,
            "s3sig" => Self::S3Signal,
            "s3upd" => Self::S3Update,
            other => panic!("unknown scenario {other}"),
        }
    }
    fn queries(self) -> usize {
        if self == Self::S0 { 0 } else { 1 }
    }
}

#[derive(Clone, Copy, PartialEq)]
enum Kind {
    First,
    Query,
    Real,
}

fn poll(t: &TestHistoryBuilder) -> PollWorkflowTaskQueueResponse {
    hist_to_poll_resp(t, WFID, ResponseType::AllHistory).resp
}

fn history_of(t: &TestHistoryBuilder) -> History {
    t.get_full_history_info().unwrap().into()
}

struct Built {
    tasks: Vec<(Kind, PollWorkflowTaskQueueResponse)>,
    history: TestHistoryBuilder,
    hist_events: usize,
    hist_bytes: usize,
    wft_count: usize,
    partial_events: usize,
}

/// History: started, WFT1, `cycles` x (WFT completed, timer started, timer fired, WFT scheduled,
/// WFT started), WFT completed, signal initiated, signal acknowledged, WFT scheduled, optional new
/// signal, WFT started. The first task delivers everything up to the last timer cycle as full
/// history; the next real task is delivered as a sticky (incremental) task.
fn build(sc: Scenario, cycles: u32) -> Built {
    let mut t = TestHistoryBuilder::default();
    t.add_by_type(EventType::WorkflowExecutionStarted);
    t.add_workflow_task_scheduled_and_started();
    for i in 1..=cycles {
        t.add_workflow_task_completed();
        let started = t.add_timer_started(i.to_string());
        t.add_timer_fired(started, i.to_string());
        t.add_workflow_task_scheduled_and_started();
    }
    let mut tasks = vec![(Kind::First, poll(&t))];
    let prev_started = t.current_event_id();
    t.add_workflow_task_completed();
    let initiated = t.add_signal_wf("wake", "signal-target", "");
    let legacy_query = |t: &TestHistoryBuilder| {
        let mut query = poll(t);
        query.query = Some(WorkflowQuery {
            query_type: "progress".to_owned(),
            ..Default::default()
        });
        query.started_event_id = 0;
        query.previous_started_event_id = prev_started;
        (Kind::Query, query)
    };
    if sc == Scenario::S1 {
        tasks.push(legacy_query(&t));
    }
    t.add_external_signal_completed(initiated);
    t.add_workflow_task_scheduled();
    if matches!(sc, Scenario::S2 | Scenario::S3Signal | Scenario::S3Update) {
        tasks.push(legacy_query(&t));
    }
    if sc == Scenario::S3Signal {
        t.add_we_signaled("poke", vec![]);
    }
    t.add_workflow_task_started();
    let full = history_of(&t);
    let wft_count = full
        .events
        .iter()
        .filter(|e| e.event_type() == EventType::WorkflowTaskStarted)
        .count();
    let mut real = hist_to_poll_resp(&t, WFID, ResponseType::OneTask(wft_count)).resp;
    let partial = real.history.as_ref().unwrap().events.clone();
    assert_eq!(
        partial.first().unwrap().event_type(),
        EventType::WorkflowTaskCompleted
    );
    assert_eq!(partial.last().unwrap().event_id, t.current_event_id());
    if sc == Scenario::S3Update {
        real.add_update_request(UPDATE_ID, real.started_event_id - 1);
    }
    tasks.push((Kind::Real, real));
    Built {
        tasks,
        hist_events: full.events.len(),
        hist_bytes: full.encoded_len(),
        wft_count,
        partial_events: partial.len(),
        history: t,
    }
}

/// Appends the events the server records for a workflow task completion, in command order.
fn commit(t: &mut TestHistoryBuilder, commands: &[Command], messages: &[ProtocolMessage]) {
    t.add_workflow_task_completed();
    let completed_id = t.current_event_id();
    let mut accepted_id = 0;
    for c in commands {
        match &c.attributes {
            Some(CmdAttrs::ModifyWorkflowPropertiesCommandAttributes(a)) => {
                t.add(WorkflowPropertiesModifiedEventAttributes {
                    workflow_task_completed_event_id: completed_id,
                    upserted_memo: a.upserted_memo.clone(),
                });
            }
            Some(CmdAttrs::StartTimerCommandAttributes(a)) => {
                t.add(TimerStartedEventAttributes {
                    timer_id: a.timer_id.clone(),
                    start_to_fire_timeout: a.start_to_fire_timeout,
                    workflow_task_completed_event_id: completed_id,
                });
            }
            Some(CmdAttrs::ProtocolMessageCommandAttributes(a)) => {
                let msg = messages
                    .iter()
                    .find(|m| m.id == a.message_id)
                    .expect("protocol message command must reference a sent message");
                if msg.id.ends_with("/accept") {
                    accepted_id = t.add_update_accepted(UPDATE_ID, "update_fn");
                } else {
                    t.add_update_completed(accepted_id);
                }
            }
            other => panic!("unexpected command {other:?}"),
        }
    }
}

/// Cold replay on a fresh replay worker. Returns ("ok" | "nde" | "error:...", activations).
async fn cold_replay(
    history: TestHistoryBuilder,
    mut lang: impl FnMut(&WorkflowActivation) -> Vec<workflow_command::Variant>,
) -> (String, usize) {
    let worker = init_replay_worker(ReplayWorkerInput::new(
        test_worker_cfg().build().unwrap(),
        stream::iter([HistoryForReplay::from(history)]),
    ))
    .unwrap();
    let mut verdict = "ok".to_string();
    let mut acts = 0;
    loop {
        let act = match worker.poll_workflow_activation().await {
            Ok(act) => act,
            Err(PollError::ShutDown) => break,
            Err(e) => {
                verdict = format!("error:{e:?}");
                break;
            }
        };
        acts += 1;
        let cmds = if let Some(reason) = act.eviction_reason() {
            if reason == EvictionReason::Nondeterminism {
                verdict = "nde".to_string();
            }
            vec![]
        } else {
            lang(&act)
        };
        worker
            .complete_workflow_activation(WorkflowActivationCompletion::from_cmds(
                act.run_id, cmds,
            ))
            .await
            .unwrap();
    }
    (verdict, acts)
}

fn cmd_types(cmds: &[Command]) -> String {
    cmds.iter()
        .map(|c| c.command_type().as_str_name().trim_start_matches("COMMAND_TYPE_"))
        .collect::<Vec<_>>()
        .join("+")
}

async fn run_core_scenario(sc: Scenario, cycles: u32, verify: bool) -> String {
    let built = build(sc, cycles);
    let full_history = history_of(&built.history);
    let fetch_bytes = GetWorkflowExecutionHistoryResponse {
        history: Some(full_history.clone()),
        ..Default::default()
    }
    .encoded_len();
    let obs = Arc::new(Mutex::new(Obs::default()));
    let answered = Arc::new(Notify::new());
    let all_answered = Arc::new(Notify::new());
    let expected_calls = built.tasks.len();
    let record = {
        let obs = obs.clone();
        let answered = answered.clone();
        let all_answered = all_answered.clone();
        move |f: &dyn Fn(&mut Obs)| {
            let mut o = obs.lock().unwrap();
            f(&mut o);
            if o.server_calls() >= expected_calls {
                o.last_answer = Some(Instant::now());
                all_answered.notify_one();
            }
            answered.notify_one();
        }
    };
    let mut client = mock_worker_client();
    {
        let record = record.clone();
        client
            .expect_complete_workflow_task()
            .returning(move |c: WorkflowTaskCompletion, _| {
                record(&|o: &mut Obs| {
                    if o.probe.t0.is_some() && o.probe.t1.is_none() {
                        o.probe.stop();
                    }
                    o.completions
                        .push((Instant::now(), c.commands.clone(), c.messages.clone()));
                });
                Ok(Default::default())
            });
    }
    {
        let record = record.clone();
        client.expect_respond_legacy_query().returning(move |_, _| {
            record(&|o: &mut Obs| o.query_answered.push(Instant::now()));
            Ok(RespondQueryTaskCompletedResponse::default())
        });
    }
    {
        let record = record.clone();
        client
            .expect_fail_workflow_task()
            .returning(move |_, _, failure| {
                let message = failure.map(|f| f.message).unwrap_or_default();
                record(&|o: &mut Obs| o.wft_failures.push(message.clone()));
                Ok(Default::default())
            });
    }
    {
        let obs = obs.clone();
        client
            .expect_get_workflow_execution_history()
            .returning(move |_, _, _| {
                obs.lock()
                    .unwrap()
                    .fetches
                    .push((Instant::now(), fetch_bytes));
                Ok(GetWorkflowExecutionHistoryResponse {
                    history: Some(full_history.clone()),
                    ..Default::default()
                })
            });
    }
    let tasks = {
        let obs = obs.clone();
        let answered = answered.clone();
        stream::iter(built.tasks)
            .then(move |(kind, resp)| {
                let obs = obs.clone();
                let answered = answered.clone();
                async move {
                    if kind != Kind::First {
                        answered.notified().await;
                    }
                    let mut o = obs.lock().unwrap();
                    match kind {
                        Kind::First => o.first_yield = Some(Instant::now()),
                        Kind::Query => o.query_sent.push(Instant::now()),
                        Kind::Real => o.probe.start(),
                    }
                    resp
                }
            })
            .chain(stream::pending())
    };
    let mut mock = MocksHolder::from_wft_stream(client, tasks);
    mock.worker_cfg(|wc| wc.max_cached_workflows = 1);
    let core = mock_worker(mock);
    loop {
        let act = tokio::select! {
            biased;
            _ = all_answered.notified() => break,
            act = core.poll_workflow_activation() => act.unwrap(),
        };
        let jobs = job_names(&act);
        obs.lock()
            .unwrap()
            .activations
            .push((Instant::now(), jobs.clone(), act.is_replaying));
        let completion = if jobs.contains(&"Evict") {
            WorkflowActivationCompletion::empty(act.run_id.clone())
        } else {
            WorkflowActivationCompletion::from_cmds(act.run_id.clone(), bench_lang(cycles, &act))
        };
        core.complete_workflow_activation(completion).await.unwrap();
    }
    core.drain_pollers_and_shutdown().await;
    let o = std::mem::take(&mut *obs.lock().unwrap());

    let p = &o.probe;
    let win_acts: Vec<_> = o.activations.iter().filter(|a| p.in_window(a.0)).collect();
    let win_evicts = win_acts.iter().filter(|a| a.1.contains(&"Evict")).count();
    let win_replay = win_acts.iter().filter(|a| a.2).count();
    let win_fetch: Vec<_> = o.fetches.iter().filter(|f| p.in_window(f.0)).collect();
    let total_evicts = o
        .activations
        .iter()
        .filter(|a| a.1.contains(&"Evict"))
        .count();
    let progress = o
        .completions
        .iter()
        .flat_map(|(_, cmds, _)| cmds)
        .filter(|c| {
            matches!(
                c.attributes,
                Some(CmdAttrs::ModifyWorkflowPropertiesCommandAttributes(_))
            )
        })
        .count();
    let first_ok = o
        .completions
        .first()
        .is_some_and(|(_, cmds, _)| cmd_types(cmds) == "SIGNAL_EXTERNAL_WORKFLOW_EXECUTION");
    let q_lat = match (o.query_sent.last(), o.query_answered.last()) {
        (Some(a), Some(b)) => (*b - *a).as_nanos() as i128,
        _ => -1,
    };
    let e2e = match (o.first_yield, o.last_answer) {
        (Some(a), Some(b)) => (b - a).as_nanos() as i128,
        _ => -1,
    };
    let real_cmds = o
        .completions
        .get(1)
        .map(|(_, c, _)| cmd_types(c))
        .unwrap_or_default();

    let (replay, replay_acts) = if verify {
        if o.completions.len() == 2 && o.wft_failures.is_empty() {
            let mut h = built.history;
            let (_, cmds, msgs) = &o.completions[1];
            commit(&mut h, cmds, msgs);
            cold_replay(h, |a| bench_lang(cycles, a)).await
        } else {
            ("live-failed".to_string(), 0)
        }
    } else {
        ("skip".to_string(), 0)
    };

    format!(
        "\"hist_events\":{},\"hist_bytes\":{},\"wft_count\":{},\"partial_events\":{},\
         \"lat_ns\":{},\"cpu_ns\":{},\"rss0_kb\":{},\"hwm_kb\":{},\"q_lat_ns\":{},\"e2e_ns\":{},\
         \"win_acts\":{},\"win_replay_acts\":{},\"win_evicts\":{},\"win_fetches\":{},\
         \"win_fetch_bytes\":{},\"total_acts\":{},\"total_evicts\":{},\"total_fetches\":{},\
         \"completions\":{},\"failures\":{},\"query_responses\":{},\"expected_queries\":{},\
         \"progress_commits\":{},\"first_cmds_ok\":{},\"real_cmds\":\"{}\",\"replay\":\"{}\",\
         \"replay_acts\":{},\"la_executions\":0,\"win_la_executions\":0",
        built.hist_events,
        built.hist_bytes,
        built.wft_count,
        built.partial_events,
        p.lat_ns(),
        p.cpu1.saturating_sub(p.cpu0),
        p.rss0_kb,
        p.hwm1_kb,
        q_lat,
        e2e,
        win_acts.len(),
        win_replay,
        win_evicts,
        win_fetch.len(),
        win_fetch.iter().map(|f| f.1).sum::<usize>(),
        o.activations.len(),
        total_evicts,
        o.fetches.len(),
        o.completions.len(),
        o.wft_failures.len(),
        o.query_answered.len(),
        sc.queries(),
        progress,
        first_ok,
        real_cmds,
        replay.replace('"', "'"),
        replay_acts,
    )
}

// ---------------------------------------------------------------------------------------------
// S4: the W4 workload (`legacy_query_acknowledging_signal_with_held_la_result_replays_like_live`
// in local_activities.rs on A/B), ported to a lib test with timing probes.
// ---------------------------------------------------------------------------------------------

/// After a timer, starts a local activity and signals another workflow, then once that signal is
/// acknowledged records whether the local activity had already finished: a memo if not, a timer
/// if so. Identical decision logic to W4's `AckThenLocalActivityWf`.
#[derive(Default)]
struct AckThenLa {
    acked: bool,
    la_done: bool,
    decided_with_la_done: Option<bool>,
}

impl AckThenLa {
    fn activate(&mut self, activation: &WorkflowActivation) -> Vec<workflow_command::Variant> {
        let mut commands = vec![];
        for job in &activation.jobs {
            match job.variant.as_ref().unwrap() {
                Job::InitializeWorkflow(_) => {
                    commands.push(start_timer_cmd(1, Duration::from_secs(1)));
                }
                Job::FireTimer(_) => {
                    commands.push(schedule_local_activity_cmd(
                        1,
                        "1",
                        ActivityCancellationType::TryCancel,
                        Duration::from_secs(60),
                    ));
                    commands.push(signal_external());
                }
                Job::ResolveSignalExternalWorkflow(_) => self.acked = true,
                Job::ResolveActivity(_) => self.la_done = true,
                unexpected => panic!("Unexpected activation job: {unexpected:?}"),
            }
        }
        if self.acked && self.decided_with_la_done.is_none() {
            self.decided_with_la_done = Some(self.la_done);
            commands.push(if self.la_done {
                start_timer_cmd(2, Duration::from_secs(10))
            } else {
                memo()
            });
        }
        commands
    }
}

fn task_with_queries(history: &TestHistoryBuilder, queries: &[&str]) -> PollWorkflowTaskQueueResponse {
    let mut task = poll(history);
    task.queries = queries
        .iter()
        .map(|id| {
            (
                (*id).to_owned(),
                WorkflowQuery {
                    query_type: "query-type".to_owned(),
                    ..Default::default()
                },
            )
        })
        .collect();
    task
}

fn query_ids(activation: &WorkflowActivation) -> Vec<String> {
    activation
        .jobs
        .iter()
        .filter_map(|j| match &j.variant {
            Some(Job::QueryWorkflow(q)) => Some(q.query_id.clone()),
            _ => None,
        })
        .collect()
}

fn has_cmd(c: &WorkflowTaskCompletion, ty: CommandType) -> bool {
    c.commands.iter().any(|c| c.command_type() == ty)
}

fn record_completion(t: &mut TestHistoryBuilder, completion: &WorkflowTaskCompletion) {
    t.add_workflow_task_completed();
    if let Some(history_event::Attributes::WorkflowTaskCompletedEventAttributes(attrs)) =
        t.last_event().and_then(|e| e.attributes.as_mut())
    {
        attrs.sdk_metadata = Some(completion.sdk_metadata.clone());
    }
    let wft_completed_id = t.current_event_id();
    for command in &completion.commands {
        match command.attributes.clone().unwrap() {
            CmdAttrs::StartTimerCommandAttributes(timer) => {
                t.add_timer_started(timer.timer_id);
            }
            CmdAttrs::RecordMarkerCommandAttributes(marker) => {
                t.add(history_event::Attributes::MarkerRecordedEventAttributes(
                    MarkerRecordedEventAttributes {
                        marker_name: marker.marker_name,
                        details: marker.details,
                        header: marker.header,
                        failure: marker.failure,
                        workflow_task_completed_event_id: wft_completed_id,
                    },
                ));
            }
            CmdAttrs::CompleteWorkflowExecutionCommandAttributes(_) => {
                t.add_workflow_execution_completed();
            }
            CmdAttrs::SignalExternalWorkflowExecutionCommandAttributes(signal) => {
                t.add_signal_wf(
                    signal.signal_name,
                    signal.execution.map(|e| e.workflow_id).unwrap_or_default(),
                    "",
                );
            }
            CmdAttrs::ModifyWorkflowPropertiesCommandAttributes(props) => {
                t.add(WorkflowPropertiesModifiedEventAttributes {
                    workflow_task_completed_event_id: wft_completed_id,
                    upserted_memo: props.upserted_memo,
                });
            }
            unexpected => panic!("Unexpected command: {unexpected:?}"),
        }
    }
}

async fn run_s4(verify: bool, la_delay: Duration) -> String {
    let mut history = TestHistoryBuilder::default();
    history.add_wfe_started_with_wft_timeout(Duration::from_secs(1));
    history.add_workflow_task_scheduled_and_started();
    let (tasks, next_tasks) = mpsc::unbounded_channel();
    tasks.send(task_with_queries(&history, &[])).unwrap();
    let obs = Arc::new(Mutex::new(Obs::default()));
    let current_history = Arc::new(Mutex::new(history_of(&history)));
    let (completion_tx, mut completions) = mpsc::unbounded_channel();
    let mut client = mock_worker_client();
    {
        let obs = obs.clone();
        client
            .expect_complete_workflow_task()
            .returning(move |completion: WorkflowTaskCompletion, _| {
                let mut o = obs.lock().unwrap();
                if o.probe.t0.is_some()
                    && o.probe.t1.is_none()
                    && has_cmd(&completion, CommandType::RecordMarker)
                {
                    o.probe.stop();
                }
                o.completions.push((
                    Instant::now(),
                    completion.commands.clone(),
                    completion.messages.clone(),
                ));
                let _ = completion_tx.send(completion);
                Ok(Default::default())
            });
    }
    {
        let obs = obs.clone();
        client.expect_respond_legacy_query().returning(move |_, _| {
            obs.lock().unwrap().query_answered.push(Instant::now());
            Ok(Default::default())
        });
    }
    {
        let obs = obs.clone();
        client
            .expect_fail_workflow_task()
            .returning(move |_, _, failure| {
                let message = failure.map(|f| f.message).unwrap_or_default();
                obs.lock().unwrap().wft_failures.push(message);
                Ok(Default::default())
            });
    }
    {
        let obs = obs.clone();
        let current_history = current_history.clone();
        client
            .expect_get_workflow_execution_history()
            .returning(move |_, _, _| {
                let h = current_history.lock().unwrap().clone();
                let resp = GetWorkflowExecutionHistoryResponse {
                    history: Some(h),
                    ..Default::default()
                };
                obs.lock()
                    .unwrap()
                    .fetches
                    .push((Instant::now(), resp.encoded_len()));
                Ok(resp)
            });
    }
    let mut mock = MocksHolder::from_wft_stream(
        client,
        tokio_stream::wrappers::UnboundedReceiverStream::new(next_tasks),
    );
    mock.worker_cfg(|wc| wc.max_cached_workflows = 1);
    let core = mock_worker(mock);
    let mut workflow = AckThenLa::default();
    let record_act = |obs: &Arc<Mutex<Obs>>, act: &WorkflowActivation| {
        obs.lock()
            .unwrap()
            .activations
            .push((Instant::now(), job_names(act), act.is_replaying));
    };
    obs.lock().unwrap().first_yield = Some(Instant::now());

    let activation = core.poll_workflow_activation().await.unwrap();
    record_act(&obs, &activation);
    let run_id = activation.run_id.clone();
    core.complete_workflow_activation(WorkflowActivationCompletion::from_cmds(
        activation.run_id.clone(),
        workflow.activate(&activation),
    ))
    .await
    .unwrap();
    record_completion(&mut history, &completions.recv().await.unwrap());
    history.add_timer_fired(history.current_event_id(), "1".to_owned());
    history.add_workflow_task_scheduled_and_started();
    tasks.send(task_with_queries(&history, &["q"])).unwrap();
    let activation = core.poll_workflow_activation().await.unwrap();
    record_act(&obs, &activation);
    core.complete_workflow_activation(WorkflowActivationCompletion::from_cmds(
        activation.run_id.clone(),
        workflow.activate(&activation),
    ))
    .await
    .unwrap();
    let query = core.poll_workflow_activation().await.unwrap();
    record_act(&obs, &query);
    assert_eq!(query_ids(&query), ["q"]);
    // The local activity finishes while lang answers the attached query, so its result is held for
    // the task the query completion forces.
    let local_activity = core.poll_activity_task().await.unwrap();
    obs.lock().unwrap().la_executions.push(Instant::now());
    if !la_delay.is_zero() {
        tokio::time::sleep(la_delay).await;
    }
    core.complete_activity_task(ActivityTaskCompletion {
        task_token: local_activity.task_token,
        result: Some(ActivityExecutionResult::ok(vec![1].into())),
    })
    .await
    .unwrap();
    core.complete_workflow_activation(WorkflowActivationCompletion::from_cmd(
        query.run_id,
        query_ok("q", "answer"),
    ))
    .await
    .unwrap();
    let completion = completions.recv().await.unwrap();
    assert!(completion.force_create_new_workflow_task);
    assert_eq!(
        completion
            .commands
            .iter()
            .map(|c| c.command_type())
            .collect::<Vec<_>>(),
        [CommandType::SignalExternalWorkflowExecution]
    );
    record_completion(&mut history, &completion);
    let initiated_id = history.current_event_id();

    history.add_workflow_task_scheduled();
    history.add_external_signal_completed(initiated_id);
    let mut legacy_query = task_with_queries(&history, &[]);
    legacy_query.query = Some(WorkflowQuery {
        query_type: "query-type".to_owned(),
        ..Default::default()
    });
    legacy_query.started_event_id = 0;
    obs.lock().unwrap().query_sent.push(Instant::now());
    tasks.send(legacy_query).unwrap();
    let activation = core.poll_workflow_activation().await.unwrap();
    record_act(&obs, &activation);
    assert_eq!(job_names(&activation), ["ResolveSignalExternal"]);
    core.complete_workflow_activation(WorkflowActivationCompletion::from_cmds(
        activation.run_id.clone(),
        workflow.activate(&activation),
    ))
    .await
    .unwrap();
    assert_eq!(workflow.decided_with_la_done, Some(false));
    let activation = core.poll_workflow_activation().await.unwrap();
    record_act(&obs, &activation);
    assert_eq!(query_ids(&activation), [LEGACY_QUERY_ID]);
    core.complete_workflow_activation(WorkflowActivationCompletion::from_cmd(
        activation.run_id,
        query_ok(LEGACY_QUERY_ID, "answer"),
    ))
    .await
    .unwrap();

    history.add_workflow_task_started();
    *current_history.lock().unwrap() = history_of(&history);
    let full = history_of(&history);
    let hist_events = full.events.len();
    let hist_bytes = full.encoded_len();
    let wft_count = full
        .events
        .iter()
        .filter(|e| e.event_type() == EventType::WorkflowTaskStarted)
        .count();
    obs.lock().unwrap().probe.start();
    tasks.send(task_with_queries(&history, &[])).unwrap();
    // Run until the task that records the local activity's marker completes, executing the local
    // activity again if the held result was dropped.
    let local_activities = {
        let obs = obs.clone();
        let core = &core;
        async move {
            loop {
                let task = core.poll_activity_task().await.unwrap();
                obs.lock().unwrap().la_executions.push(Instant::now());
                if !la_delay.is_zero() {
                    tokio::time::sleep(la_delay).await;
                }
                core.complete_activity_task(ActivityTaskCompletion {
                    task_token: task.task_token,
                    result: Some(ActivityExecutionResult::ok(vec![1].into())),
                })
                .await
                .unwrap();
            }
        }
    };
    let workflow_tasks = async {
        loop {
            tokio::select! {
                biased;
                completion = completions.recv() => {
                    let completion = completion.unwrap();
                    record_completion(&mut history, &completion);
                    if has_cmd(&completion, CommandType::RecordMarker) {
                        return;
                    }
                    if completion.force_create_new_workflow_task {
                        history.add_workflow_task_scheduled_and_started();
                        *current_history.lock().unwrap() = history_of(&history);
                        tasks.send(task_with_queries(&history, &[])).unwrap();
                    }
                }
                activation = core.poll_workflow_activation() => {
                    let activation = activation.unwrap();
                    record_act(&obs, &activation);
                    let cmds = if activation.eviction_reason().is_some() {
                        workflow = AckThenLa::default();
                        vec![]
                    } else {
                        workflow.activate(&activation)
                    };
                    core.complete_workflow_activation(WorkflowActivationCompletion::from_cmds(
                        activation.run_id.clone(),
                        cmds,
                    ))
                    .await
                    .unwrap();
                }
            }
        }
    };
    tokio::select! {
        _ = local_activities => unreachable!(),
        _ = workflow_tasks => {},
    }
    obs.lock().unwrap().last_answer = Some(Instant::now());

    core.request_workflow_eviction(&run_id);
    let eviction = core.poll_workflow_activation().await.unwrap();
    assert!(eviction.eviction_reason().is_some());
    core.complete_workflow_activation(WorkflowActivationCompletion::empty(eviction.run_id))
        .await
        .unwrap();
    core.drain_pollers_and_shutdown().await;
    let o = std::mem::take(&mut *obs.lock().unwrap());
    let p = &o.probe;

    let win_acts: Vec<_> = o.activations.iter().filter(|a| p.in_window(a.0)).collect();
    let win_evicts = win_acts.iter().filter(|a| a.1.contains(&"Evict")).count();
    let win_replay = win_acts.iter().filter(|a| a.2).count();
    let win_fetch: Vec<_> = o.fetches.iter().filter(|f| p.in_window(f.0)).collect();
    let markers = history_of(&history)
        .events
        .iter()
        .filter(|e| e.event_type() == EventType::MarkerRecorded)
        .count();
    let last_cmds = o
        .completions
        .last()
        .map(|(_, c, _)| cmd_types(c))
        .unwrap_or_default();
    let (replay, replay_acts) = if verify {
        let mut wf = AckThenLa::default();
        cold_replay(history, move |a| wf.activate(a)).await
    } else {
        ("skip".to_string(), 0)
    };
    format!(
        "\"hist_events\":{},\"hist_bytes\":{},\"wft_count\":{},\"partial_events\":{},\
         \"lat_ns\":{},\"cpu_ns\":{},\"rss0_kb\":{},\"hwm_kb\":{},\"q_lat_ns\":{},\"e2e_ns\":{},\
         \"win_acts\":{},\"win_replay_acts\":{},\"win_evicts\":{},\"win_fetches\":{},\
         \"win_fetch_bytes\":{},\"total_acts\":{},\"total_evicts\":{},\"total_fetches\":{},\
         \"completions\":{},\"failures\":{},\"query_responses\":{},\"expected_queries\":1,\
         \"progress_commits\":{},\"first_cmds_ok\":true,\"real_cmds\":\"{}\",\"replay\":\"{}\",\
         \"replay_acts\":{},\"la_executions\":{},\"win_la_executions\":{},\"markers\":{},\
         \"la_delay_ms\":{}",
        hist_events,
        hist_bytes,
        wft_count,
        hist_events,
        p.lat_ns(),
        p.cpu1.saturating_sub(p.cpu0),
        p.rss0_kb,
        p.hwm1_kb,
        match (o.query_sent.last(), o.query_answered.last()) {
            (Some(a), Some(b)) => (*b - *a).as_nanos() as i128,
            _ => -1,
        },
        match (o.first_yield, o.last_answer) {
            (Some(a), Some(b)) => (b - a).as_nanos() as i128,
            _ => -1,
        },
        win_acts.len(),
        win_replay,
        win_evicts,
        win_fetch.len(),
        win_fetch.iter().map(|f| f.1).sum::<usize>(),
        o.activations.len(),
        o.activations
            .iter()
            .filter(|a| a.1.contains(&"Evict"))
            .count(),
        o.fetches.len(),
        o.completions.len(),
        o.wft_failures.len(),
        o.query_answered.len(),
        o.completions
            .iter()
            .flat_map(|(_, cmds, _)| cmds)
            .filter(|c| {
                matches!(
                    c.attributes,
                    Some(CmdAttrs::ModifyWorkflowPropertiesCommandAttributes(_))
                )
            })
            .count(),
        last_cmds,
        replay.replace('"', "'"),
        replay_acts,
        o.la_executions.len(),
        o.la_executions.iter().filter(|t| p.in_window(**t)).count(),
        markers,
        la_delay.as_millis(),
    )
}

fn env_num<T: std::str::FromStr>(key: &str, default: T) -> T {
    std::env::var(key)
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(default)
}

#[tokio::test]
async fn perf_bench_1766() {
    let Ok(scenario) = std::env::var("B1766_SCENARIO") else {
        return;
    };
    let cycles: u32 = env_num("B1766_CYCLES", 0);
    let samples: usize = env_num("B1766_SAMPLES", 30);
    let warmup: usize = env_num("B1766_WARMUP", 5);
    let verify = std::env::var("B1766_VERIFY").is_ok_and(|v| v == "1");
    let la_delay = Duration::from_millis(env_num("B1766_LA_DELAY_MS", 0));
    let label = std::env::var("B1766_LABEL").unwrap_or_default();
    let round: usize = env_num("B1766_ROUND", 0);
    let out = std::env::var("B1766_OUT").expect("B1766_OUT must be set");
    let mut file = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(out)
        .unwrap();
    for i in 0..warmup + samples {
        let fut = async {
            if scenario == "s4" {
                run_s4(verify, la_delay).await
            } else {
                run_core_scenario(Scenario::parse(&scenario), cycles, verify).await
            }
        };
        let rec = tokio::time::timeout(Duration::from_secs(300), fut)
            .await
            .expect("sample timed out");
        writeln!(
            file,
            "{{\"label\":\"{label}\",\"scenario\":\"{scenario}\",\"cycles\":{cycles},\
             \"round\":{round},\"i\":{i},\"warmup\":{},\"verify\":{verify},{rec}}}",
            i < warmup
        )
        .unwrap();
    }
}
