#!/usr/bin/env bash
# Usage: check_identity.sh <commit>
# Proves the build tree equals <commit> byte-for-byte except the benchmark additions.
set -euo pipefail
I=/home/researcher/oss/investigations/sdk-rust-1766-perf-20261125
REPO=/home/researcher/oss/worktrees/rust-review
C=$(git -C $REPO rev-parse "$1^{commit}")
cd $I/tree
git -C $REPO ls-tree -r "$C" | awk '$2=="blob"{print $3"\t"$4}' | sort -k2 > /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_commit.$$ 
cut -f2 /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_commit.$$ | while IFS= read -r p; do [ -e "$p" ] && printf '%s\t%s\n' "$(git hash-object --no-filters -- "$p")" "$p" || printf 'MISSING\t%s\n' "$p"; done | sort -k2 > /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_tree.$$
echo "commit $C"
echo "-- files differing from commit:"; join -t$'\t' -1 2 -2 2 /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_commit.$$ /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_tree.$$ | awk -F'\t' '$2!=$3{print "  "$1}'
echo "-- files in tree not in commit:"; find . -type f | sed 's|^\./||' | sort > /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_files_tree.$$; cut -f2 /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_commit.$$ | sort > /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_files_commit.$$; comm -23 /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_files_tree.$$ /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_files_commit.$$ | sed 's/^/  /'
echo "-- production diff vs upstream (sha256 of git diff over sdk-core/src/worker):"
git -C $REPO diff 6eaaeebaa5d90e573e7bed5152c9b5dfca75dc08 "$C" -- crates/sdk-core/src/worker/workflow/managed_run.rs crates/sdk-core/src/worker/workflow/machines/workflow_machines.rs crates/sdk-core/src/worker/workflow/machines/workflow_machines/local_acts.rs | sha256sum
echo "-- sha256 of tree production files:"; sha256sum crates/sdk-core/src/worker/workflow/managed_run.rs crates/sdk-core/src/worker/workflow/machines/workflow_machines.rs crates/sdk-core/src/worker/workflow/machines/workflow_machines/local_acts.rs
echo "-- bench module sha256:"; sha256sum crates/sdk-core/src/core_tests/perf_bench_1766.rs
rm -f /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_commit.$$ /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_idx_tree.$$ /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_files_tree.$$ /home/researcher/oss/investigations/sdk-rust-1766-perf-20261125/.tmp_files_commit.$$
