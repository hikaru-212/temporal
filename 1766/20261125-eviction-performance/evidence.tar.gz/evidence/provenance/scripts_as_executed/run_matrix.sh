#!/usr/bin/env bash
# Usage: run_matrix.sh <out.jsonl> <scenario> <cycles> <rounds> <samples_per_round> <warmup> <verify 0|1> <labels...>
# Alternates versions every round and reverses their order on odd rounds (ABBA style) so drift and
# background noise hit every version alike. Each invocation is a fresh process.
set -euo pipefail
I=/home/researcher/oss/investigations/sdk-rust-1766-perf-20261125
OUT=$1; SC=$2; K=$3; R=$4; S=$5; W=$6; V=$7; shift 7; LABELS=("$@")
for ((r=0; r<R; r++)); do
  if (( r % 2 )); then order=($(printf '%s\n' "${LABELS[@]}" | tac)); else order=("${LABELS[@]}"); fi
  for L in "${order[@]}"; do
    B1766_SCENARIO=$SC B1766_CYCLES=$K B1766_SAMPLES=$S B1766_WARMUP=$W B1766_VERIFY=$V \
    B1766_LABEL=$L B1766_ROUND=$r B1766_OUT=$OUT B1766_LA_DELAY_MS=${LA_DELAY_MS:-0} \
      taskset -c 1-4 $I/bins/$L/sdk_core_lib_tests --exact core_tests::perf_bench_1766::perf_bench_1766 \
      --test-threads=1 -q > /dev/null 2>>$I/raw/stderr_${SC}_${K}_${L}.log \
      || { echo "FAILED: $L $SC $K round $r" >&2; tail -20 $I/raw/stderr_${SC}_${K}_${L}.log >&2; }
  done
done
