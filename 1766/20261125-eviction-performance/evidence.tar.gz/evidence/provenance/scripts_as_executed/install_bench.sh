#!/usr/bin/env bash
# Copies the benchmark module into the build tree and registers it in core_tests/mod.rs.
set -euo pipefail
I=/home/researcher/oss/investigations/sdk-rust-1766-perf-20261125
T=$I/tree/crates/sdk-core/src/core_tests
cp $I/bench/perf_bench_1766.rs $T/perf_bench_1766.rs
grep -qx 'mod perf_bench_1766;' $T/mod.rs || echo 'mod perf_bench_1766;' >> $T/mod.rs
