#!/usr/bin/env bash
# Usage: build.sh <label> ; builds the lib test binary of the current tree in release, under a disk guard,
# then copies the test binary to bins/<label>/.
set -uo pipefail
I=/home/researcher/oss/investigations/sdk-rust-1766-perf-20261125
L=$1
cd $I/tree
echo "start $(date -Is) avail=$(df -B1 --output=avail / | tail -1)"
setsid bash -c "CARGO_TARGET_DIR=$I/target cargo test -p temporalio-sdk-core --lib --release --locked --offline --no-run -j 4 --message-format=json-render-diagnostics > $I/raw/build_$L.json" &
pid=$!
sleep 1
$I/scripts/disk_guard.sh $pid &
wait $pid; rc=$?
echo "cargo rc=$rc end $(date -Is) avail=$(df -B1 --output=avail / | tail -1)"
exe=$(grep '"executable":"[^"]*temporalio_sdk_core-[0-9a-f]*"' -o $I/raw/build_$L.json | tail -1 | sed 's/"executable":"//;s/"$//')
echo "exe=$exe"
if [ $rc -eq 0 ] && [ -n "$exe" ]; then mkdir -p $I/bins/$L; cp "$exe" $I/bins/$L/sdk_core_lib_tests; sha256sum $I/bins/$L/sdk_core_lib_tests; fi
exit $rc
