#!/usr/bin/env bash
# Usage: disk_guard.sh <pgid> ; kills the process group if free space on / drops below 25.3 GiB.
set -u
while kill -0 -- "-$1" 2>/dev/null; do
  avail=$(df -B1 --output=avail / | tail -1)
  if [ "$avail" -lt $((253*2**30/10)) ]; then
    echo "$(date -Is) DISK GUARD: avail=$avail bytes, killing pgid $1" >&2
    kill -TERM -- "-$1"; sleep 2; kill -KILL -- "-$1" 2>/dev/null; exit 1
  fi
  sleep 2
done
