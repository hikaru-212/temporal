# Temporal SDK Rust #1766 — Conservative Eviction 效能代價評估

2026-11-25（UTC）。本報告只量化取捨，不重新開啟 correctness investigation，也沒有修改修復。

## 結論摘要

| 問題 | 答案（Core-level，release build，synthetic lang，mock server） |
|---|---|
| 普通 Hot Path（S0）與 non-effectful query（S1）是否有可量測影響？ | **沒有。** 8 組比較的 B−A 中位數差都在 −2.0 到 +5.7 µs 之間，95% CI 都包含 0，MWU p 都在 0.12 以上。量測解析度約 ±10–20 µs。原始碼上，B 在這條路徑只多一次 bool 判斷 |
| 額外 eviction（S2）的實測成本 | 每次約 **96 µs + 134 µs × WFT 數**（CPU 約 105 µs/WFT），再加 1 次完整 History fetch。依 History 大小：8 events +0.34 ms、98 events +3.1 ms、998 events +26.8 ms、4,998 events +134 ms、9,998 events +269 ms |
| 成本如何隨 History 長度變化 | **與 WFT 數線性相關。** log-log 斜率 0.97，20→2,000 WFT 區間的邊際成本穩定在 132–135 µs/WFT。本 workload 每個 WFT 5 個 events，所以約 27 µs/event。成本等於一次完整冷重建，跟該 run 發生一次一般 sticky cache miss 一樣 |
| A/B 都需要 eviction 時（S3、S4），B 是否更貴？ | 沒有政策層面的額外成本：activation、eviction、fetch、LA 執行次數完全相同。在最大的 S3 規模（約 5k events）觀察到 B 慢約 1%（+1.1 ms 與 +2.0 ms，p=0.043 與 0.0015），但原始碼中找不到對應機制，判定為無關緊要的殘差。S4 沒有顯著差異 |
| LA 重新執行 | S4（W4 workload）A 與 B 都把 LA 執行 2 次（下一個 WFT 的時間窗內 1 次），U 只執行 1 次但 History 無法 replay。依原始碼，**只有 B 會 evict 的情況不會造成 LA 重新執行**（見 §5.2） |
| 是否支持 correctness-first trade-off | **支持，但有一個未知數。** Hot path 零成本；原本就要 evict 的路徑沒有額外成本；只有 B 會 evict 的情況，每個 run instance 每次 effectful legacy query 最多多一次「等同 cache miss」的重建。未知的是真實環境中這種情況的發生頻率 |
| 是否有數據顯示需要重新考慮設計 | **目前沒有。** 只有在「長 History（≥1,000 WFT）」加上「effectful legacy query 占真實 WFT ≥1%」時，平均延遲才會增加到毫秒級（見 §6 的假設模型）。這是頻率資料可能推翻結論的條件，不是已觀察到的事實 |

真實 Server benchmark **沒有執行**（原因見 §8）。所有數字都不是 production latency。

---

## 0. 範圍與 source identity

| 代號 | Commit | Production diff（相對 U）sha256 | 驗證 |
|---|---|---|---|
| U | `6eaaeebaa5d90e573e7bed5152c9b5dfca75dc08` | 空 diff（`e3b0c442…`） | `evidence/identity_U.txt` |
| A | `31a1a905c26034957f3968015de45177849a2b3f` | `3a96b62d…`（3 個檔案，含 `local_acts.rs`） | `evidence/identity_A.txt` |
| B | `9a59ba3c33ac0d64035a197dc1ae103aa670a8a5`（`fix/1766-final-candidate` HEAD） | **`35f5f0c7ef1d86e1…`** | `evidence/identity_B.txt` |

- 確認了 B 的 source identity，不是只看 branch name。
  - `git diff 6eaaeeba 9a59ba3c3 | sha256sum` = `8cc838816b4cbf6c…`（最後驗證過的完整 source identity）。
  - 只取 `managed_run.rs` 與 `workflow_machines.rs` 的 diff = `35f5f0c7ef1d86e1…`（production identity）。
  - 這兩個值與 hardening 報告記錄的值逐位元相同。
- 先前報告說「HEAD 31a1a905 + 未 commit 修改」。之後這些修改已 commit 為 `9a59ba3c3`，worktree 現在是乾淨的。
- 正式 worktree `~/oss/worktrees/sdk-rust-1766-final` 只做了讀取（git diff、git show）。結束時 `git status` 乾淨，HEAD 仍是 `9a59ba3c3`。
- 建置用的 tree 由 `git archive <commit> | tar -x -m` 匯出到 investigation directory。之後以 `scripts/check_identity.sh` 逐檔比對 git blob hash，證明 tree 與該 commit 只有以下差異：
  - 新增 `core_tests/perf_bench_1766.rs`（sha256 `b610cefa…`，三個版本相同）
  - 在 `core_tests/mod.rs` 加一行 `mod perf_bench_1766;`
  - 換成 U 時，tree 還殘留 A/B 的 `legacy_query_replay.rs` 與一個 changelog `.md`。U 的 `mod.rs` 沒有宣告前者，所以兩個檔案都不會被編譯。

## 1. Benchmark 實作

### 1.1 為什麼是 lib test，而不是既有 benchmark infrastructure

- `crates/sdk-core` 有 criterion dev-dependency 與 `heavy_tests`，但沒有任何會走 legacy-query 準備路徑的 benchmark。
- B 的 `core_tests/legacy_query_replay.rs` 已經有可決定性的 mock server 與 synthetic lang 架構（`MocksHolder::from_wft_stream`、`hist_to_poll_resp`、`mock_worker`），因此直接沿用。
- 新模組 `bench/perf_bench_1766.rs`（複製進 `core_tests/`）由環境變數驅動，沒有設定時立即返回。每個樣本輸出一行 JSON。

### 1.2 計時區間

- **起點**：mock poll stream 把「下一個真正的 WFT」交給 Core 的時刻（`Probe::start`）。
- **終點**：mock server 收到這個 WFT 的 `complete_workflow_task` 的時刻（`Probe::stop`）。S4 的終點是含 `RecordMarker` 的那次 completion。
- 區間內包含：cache 重用或 eviction、RemoveFromCache activation、run 重建、從 mock 取得 History、replay、synthetic lang 處理每個 activation、completion。
- 不包含：編譯、worker 啟動、第一個 WFT 的完整 replay（setup）、cold replay 驗證。
- **synthetic lang 是幾行 Rust**，每個 activation 的成本遠低於 Python、TS 等真正的 Language SDK。所以這裡的數字是 Core 加上跨執行緒 activation 往返的下界。
- CPU 是時間窗內 `/proc/self/task/*/schedstat` 的增量，包含 Core 專用的 workflow processing thread。
- RSS 是時間窗開始時以 `clear_refs=5` 重設 VmHWM 後，結束時的 VmHWM 減 VmRSS。

### 1.3 Workload

**S0–S3 的 History：**
1. `WorkflowExecutionStarted`、WFT1
2. K 個 timer cycle，每個 cycle 為 WFTCompleted、TimerStarted、TimerFired、WFTScheduled、WFTStarted
3. WFTCompleted、SignalExternalInitiated、（S1 的 query 在此）、ExternalSignalCompleted、WFTScheduled
4. （S2、S3 的 query 在此）、（S3sig 的新 signal）、WFTStarted

**Synthetic lang：**
- Init 啟動 timer 1；timer k 觸發後啟動 timer k+1；最後一個 timer 觸發後 signal external。
- signal 被確認（ack）後 upsert memo。
- 與 Python SDK 相同，先處理 signal 與 update。
- **完全不讀 history length 或時間**。因此 S2 中 A 的重用與 B 的重建，都會產生正確且可 replay 的 History（已在 §2 驗證）。

**投遞方式：**
- 第一個 WFT 以完整 History 投遞。
- Legacy query 與既有回歸測試相同：non-sticky、完整 History、`started_event_id=0`。
- **下一個真正的 WFT 以 sticky 的增量 History 投遞**（`ResponseType::OneTask`，5 或 6 個 events）。因此 B 重建時，必須真的向 mock 呼叫 `GetWorkflowExecutionHistory`。

| 情境 | 內容 | 預期 |
|---|---|---|
| S0 | 沒有 query | A、B 都不 evict |
| S1 | query 在 ack 之前，準備期不執行 workflow code | A、B 都不 evict |
| S2 | query 在 ack 之後，準備期執行 workflow code；下一個 WFT 只帶自己的 WFTStarted | A 重用，B evict 並重建 |
| S3sig／S3upd | 同 S2，但下一個 WFT 帶新的 signal event 或 update request | A、B 都 evict |
| S4 | 移植 W4（`legacy_query_acknowledging_signal_with_held_la_result_replays_like_live`）的決策邏輯與流程，加上計時 | A、B 都 evict |

History 規模（實際值）：

| K | events | serialized bytes | WFT 數 |
|---:|---:|---:|---:|
| 0 | 8 | 283 | 2 |
| 18 | 98 | 2,623 | 20 |
| 198 | 998 | 27,967 | 200 |
| 998 | 4,998 | 142,239 | 1,000 |
| 1,998 | 9,998 | 287,237 | 2,000 |

S3sig 多 1 個 signal event。S4 是 13 events、440 bytes、3 個 WFT。不同樣本的 bytes 有幾 % 的差異，因為 timestamp 的 varint 長度不同。

### 1.4 編譯與執行環境

- **編譯**：三個版本使用同一個 tree 路徑、同一個 `CARGO_TARGET_DIR`、同一個指令：
  - `cargo test -p temporalio-sdk-core --lib --release --locked --offline --no-run -j 4`
  - Profile 為 release（opt-level 3、無 debuginfo、debug-assertions 關閉、無 LTO）。
  - Features：sdk-core 預設的 `envconfig, prometheus, tls-ring`，**沒有** `disable_workflow_task_chunking`，也就是先前報告中的「legacy／chunked」模式。
  - 依序 A → B → U。切換時只重新編譯 workspace crates（見 `raw/build_{A,B,U}.log`）。
  - 每次建置後把 test binary 複製到 `bins/<label>/`：A `b120ce8c…`、B `42e9428c…`、U `1360377c…`。
  - Toolchain：rustc／cargo 1.100.0（LLVM 23.1.5），aarch64-unknown-linux-gnu。
- **環境**：
  - VM 為 6 vCPU（Apple aarch64）、7.7 GiB RAM、Linux 6.8.0-149。
  - 所有量測都以 `taskset -c 1-4` 執行。
  - Worker 設定 `max_cached_workflows=1`，其餘使用 mock 預設值，三個版本相同。
  - 沒有安裝 tracing subscriber，三個版本的 logging 設定相同。
- **交替執行**：
  - 每次 invocation 是新的 process，先做 3 次 warm-up，再取 10 個樣本。
  - 每一輪依序跑完 A、B、U，下一輪反轉順序（ABBA 式）。
  - 每個樣本使用新的 worker 與相同的 History，所以快取狀態相同。
- **樣本數**：

  | 情境 | 每個版本的有效樣本數 |
  |---|---|
  | S2 | 100（10 輪 × 10） |
  | S0、S1、S3 | 60（6 輪 × 10） |
  | S4 | 100 |
  | S4（20 ms LA） | 30 |

  n=60 或 100 時，p99 實際上只是最大的 1–2 個值，**不具穩定統計意義**，只作參考。
- **統計方法**：中位數差、2,000 次 bootstrap 的 95% CI、雙尾 Mann–Whitney U（常態近似，含 tie 修正）。VM 上沒有 numpy，以純 Python 實作（`scripts/analyze.py`）。

## 2. Correctness control（與計時分開執行）

`raw/verify.jsonl`、`raw/verify_summary.md`：每個版本、情境、規模各 3 個樣本，共 189 個。另外 5,742 個計時樣本也記錄了同樣的結構性欄位。

| 檢查 | A | B | U |
|---|---|---|---|
| 每個樣本的 WFT completion 數符合預期（S0–S3 為 2，S4 為 3），WFT failure 為 0 | 全部符合 | 全部符合 | 全部符合 |
| Legacy query 回覆次數等於預期 | 全部符合 | 全部符合 | 全部符合 |
| 第一個 completion 的 commands 等於 `[SignalExternal]`（確認預建的 History 與 lang 一致） | 全部 | 全部 | 全部 |
| progress（memo）只 commit 1 次 | 全部 | 全部 | 全部 |
| 時間窗內的 eviction 次數符合預期 | S0、S1、S2 為 0；S3、S4 為 1 | S0、S1 為 0；**S2、S3、S4 為 1** | 全部為 0 |
| 沒有未預期的 eviction | 是 | 是 | 是 |
| Cold replay（全新的 replay worker） | **全部 ok** | **全部 ok** | S0、S1、S2 ok；**S3sig、S3upd、S4 全部 NDE** |

- 5,742 個計時樣本中：failures = 0；eviction 次數與上表完全一致；completion 與 query 回覆次數都正確。
- **U 在 S3 與 S4 會產生無法 replay 的 History**。因此 U 在這兩個情境的低延遲，**不是有效的等價工作量**，只能列為 correctness-invalid baseline。
- S4 中，lang 是「看到 ack 時 LA 是否已完成」的決策，結果取決於 LA 完成與重建 activation 的時序競爭：
  - LA 延遲 0 ms：A 為 memo 48／timer 52，B 為 53／47。
  - LA 延遲 20 ms：兩者都是 memo。
  - 兩種結果在 A、B 都能 cold replay。這是 W4 workload 本身的合法非決定性，不是任一版本的錯誤。

## 3. 各情境結果（下一個真正 WFT 的 latency）

完整表格（含 p95、p99、CPU、fetch、activation 分布）：`raw/timed_summary.md`。

### 3.1 S0 — Normal Hot Path

| History events | A median µs | B median µs | Δ µs（95% CI） | Ratio | MWU p | Evictions A/B | n |
|---:|---:|---:|---|---:|---:|---|---:|
| 98 | 120.8 | 121.0 | +0.2（−7.8…+21.5） | 1.002 | 0.22 | 0/0 | 60/60 |
| 998 | 110.0 | 114.4 | +4.4（−2.7…+9.6） | 1.040 | 0.49 | 0/0 | 60/60 |
| 4,998 | 118.2 | 123.9 | +5.7（−1.8…+12.6） | 1.048 | 0.12 | 0/0 | 60/60 |
| 9,998 | 138.2 | 139.9 | +1.6（−5.1…+11.2） | 1.012 | 0.47 | 0/0 | 60/60 |

- U 與 A 也沒有顯著差異。
- 單一 WFT 約 110–140 µs，主要是 mock stream、Core thread、lang loop 之間的跨執行緒往返。
- **結論：沒有可量測的 overhead。** B 的 diff 在這條路徑只有一次 `bool && Option::is_none()`，以及 activation 派送時的一次條件判斷，遠低於量測解析度。

### 3.2 S1 — Non-effectful Legacy Query

| History events | A median µs | B median µs | Δ µs（95% CI） | MWU p | Query latency A／B µs | Evictions A/B |
|---:|---:|---:|---|---:|---|---|
| 98 | 130.3 | 128.4 | −2.0（−9.7…+10.4） | 0.61 | 246／251 | 0/0 |
| 998 | 118.8 | 118.2 | −0.6（−6.4…+4.2） | 0.57 | 319／312 | 0/0 |
| 4,998 | 132.8 | 131.4 | −1.4（−9.5…+5.9） | 0.97 | 730／745 | 0/0 |
| 9,998 | 159.6 | 161.7 | +2.1（−3.0…+9.4） | 0.28 | 1,314／1,328 | 0/0 |

**結論：一般 query path 不受影響。** Query 本身的回覆延遲也一樣。這個延遲會隨 History 增長，因為 non-sticky legacy query 帶完整 History，但三個版本相同。

### 3.3 S2 — Effectful Legacy Query，沒有額外工作（主要情境）

| History events | WFT | A median µs | B median µs | 額外延遲 | Ratio | B p95／p99* µs | 額外 CPU | Evictions A/B | B 時間窗內 activations（replay） | B fetch 次數／bytes | n |
|---:|---:|---:|---:|---:|---:|---|---:|---|---|---|---:|
| 8 | 2 | 144.4 | 480.6 | **+0.34 ms** | 3.3× | 803／837 | +0.23 ms | 0/1 | 3（1） | 1／約 0.28 KB | 100/100 |
| 98 | 20 | 110.1 | 3,195.0 | **+3.08 ms** | 29× | 4,074／5,261 | +2.28 ms | 0/1 | 21（19） | 1／約 2.6 KB | 100/100 |
| 998 | 200 | 111.6 | 26,883.9 | **+26.8 ms** | 241× | 29,952／32,451 | +20.9 ms | 0/1 | 201（199） | 1／約 28 KB | 100/100 |
| 4,998 | 1,000 | 124.6 | 134,381.7 | **+134.3 ms** | 1,079× | 139,755／150,150 | +104.7 ms | 0/1 | 1,001（999） | 1／約 142 KB | 100/100 |
| 9,998 | 2,000 | 148.4 | 269,057.6 | **+268.9 ms** | 1,814× | 281,706／288,132 | +209.6 ms | 0/1 | 2,001（1,999） | 1／約 287 KB | 100/100 |

\* p99 不具穩定統計意義。所有比較的 MWU p 都 < 1e-33，bootstrap CI 都很窄（例如 9,998 events 為 +266.2…+270.2 ms）。

- **A 的 latency 不隨 History 變化**：
  - 準備期已經完成 workflow 的工作，所以真正的 WFT 不需要 activate lang（時間窗內 0 個 activations）。
  - Core 只套用一個 WFTStarted 並送出保留的 commands。
- **B 的時間窗內**：
  - 一次 RemoveFromCache。
  - 1 次完整 History fetch，fetch bytes 約等於完整 History 大小。
  - 從頭 replay 全部 WFT（WFT 數 − 1 個 replaying activations），再加 1 個 live activation。
- **U 與 A 沒有顯著差異**（S2 中 U 也重用，而且這個 lang 下的 History 仍可 replay）。所以 A 的 Safe Reuse Predicate 本身也沒有可量測的成本。
- **完成同一份有效工作的總時間**（每個樣本從第一個 task 到最後一個回覆，含 setup 的完整 replay）：
  - 9,998 events：A 261.7 ms，B 535.1 ms（+273 ms）。
  - 998 events：27.9 ms 對 55.0 ms。
  - 也就是說，**一次額外 eviction 大約讓該 workflow 的「建立 cache」成本多付一次**。

**RSS**：
- 多數規模的時間窗內 RSS 峰值增量中位數接近 0，因為 allocator 會重用 setup 期間釋放的記憶體。
- 只有 B 的 9,998 events 觀察到中位數 +20 MB。
- 這項指標受 allocator 影響很大，**只能視為粗略的指標**。

### 3.4 S3 — 兩個版本原本都要 evict

| 情境 | events | A median ms | B median ms | Δ（95% CI） | MWU p | Evictions A/B | Activations A/B | U（無效） |
|---|---:|---:|---:|---|---:|---|---|---|
| S3sig | 99 | 3.288 | 3.238 | −0.05 ms（−0.25…+0.15） | 0.33 | 1/1 | 21/21 | 0.131 ms，**NDE** |
| S3sig | 999 | 26.65 | 26.87 | +0.22 ms（−0.03…+0.48） | 0.024 | 1/1 | 201/201 | 0.120 ms，**NDE** |
| S3sig | 4,999 | 133.2 | 134.4 | +1.14 ms（+0.14…+1.78） | 0.043 | 1/1 | 1,001/1,001 | 0.132 ms，**NDE** |
| S3upd | 98 | 3.128 | 3.294 | +0.17 ms（−0.09…+0.45） | 0.062 | 1/1 | 21/21 | 0.140 ms，**NDE** |
| S3upd | 998 | 26.81 | 26.71 | −0.10 ms（−0.33…+0.56） | 0.25 | 1/1 | 201/201 | 0.130 ms，**NDE** |
| S3upd | 4,998 | 132.8 | 134.7 | +1.95 ms（+0.82…+2.81） | 0.0015 | 1/1 | 1,001/1,001 | 0.139 ms，**NDE** |

- A 與 B 的 eviction、activation、fetch 次數完全相同。
- 兩者走同一個 `evict_for_legacy_query_effects`。A 在 evict 之前還多算一次 predicate，所以原始碼上 A 做的工作只會更多。
- 在 4,999／4,998 events，觀察到 B 慢約 0.9–1.5%。逐輪配對比較中，B 較慢的輪數是 4/6 與 5/6。
- **原始碼中沒有任何機制能解釋這個差異**。可能來自 `managed_run.rs` 變化造成的編譯結果、程式碼佈局差異或殘餘雜訊。
- 不把它視為 conservative policy 的成本。相對 S2 的差距（數量級為 1,000 倍），它可以忽略。
- U 的延遲約 0.13 ms，但 History 無法 replay，**不能當作有效的效能優勢**。

### 3.5 S4 — 持有 LA 結果（W4）

| LA 執行時間 | A median ms | B median ms | Δ（95% CI） | MWU p | Evictions A/B | LA 執行次數（總計／時間窗內）A、B | U |
|---|---:|---:|---|---:|---|---|---|
| 0 ms（n=100） | 0.689 | 0.703 | +0.01 ms（−0.04…+0.06） | 0.58 | 1/1 | 2／1、2／1 | 0.18 ms，LA 1 次，**NDE** |
| 20 ms（n=30） | 27.38 | 30.87 | +3.5 ms（+0.35…+6.34） | 0.067 | 1/1 | 2／1、2／1 | 0.22 ms，LA 1 次，**NDE** |

- LA 延遲 20 ms 時，兩個版本的分布都在 21.5–34.1 ms 之間，大幅重疊，p > 0.05，n 也小。**沒有結論**，不視為 B 的額外成本。
- 兩者的事件序列完全相同：evict 1 次，重新執行 1 次 LA，5 個 activations。
- **額外 LA 成本**（相對於假想的、不重新執行的路徑）：每次 eviction 多 1 次 LA 執行。時間窗內的牆鐘時間約為「LA 執行時間 + 0.5–0.7 ms 的重建」。
  - 這裡的 W4 History 很短，所以重建成本小。
  - 長 History 下的重建成本依 §4 線性增加。
- 這是 A 與 B **共同**的成本，不是 B 獨有的成本。U 不需要這個成本，但 U 的 History 無法 replay。

## 4. History 規模的 scaling

| WFT | events | Δ latency | Δ/WFT | Δ/event | ΔCPU/WFT |
|---:|---:|---:|---:|---:|---:|
| 2 | 8 | 0.34 ms | 168 µs | 42 µs | 117 µs |
| 20 | 98 | 3.08 ms | 154 µs | 31 µs | 114 µs |
| 200 | 998 | 26.8 ms | 134 µs | 27 µs | 105 µs |
| 1,000 | 4,998 | 134.3 ms | 134 µs | 27 µs | 105 µs |
| 2,000 | 9,998 | 268.9 ms | 134 µs | 27 µs | 105 µs |

- 最小平方法擬合：Δlatency ≈ **134.4 µs × WFT + 96 µs**；ΔCPU ≈ 104.8 µs × WFT + 47 µs。
- log-log 斜率 0.970。
- 邊際成本：2→20 WFT 為 153 µs/WFT；20→200 為 132；200→1,000 為 134；1,000→2,000 為 135。
- 在 8 到 9,998 events 的範圍內，**實測是線性**，沒有看到超線性的跡象。
- 成本由「需要 replay 的 WFT 或 activation 數」決定，而不是單純由 event 數決定。
  - 本 workload 每個 WFT 是 5 個 events、1 個 timer。
  - 每個 WFT 有更多 events 或 commands 的 workflow，per-event 成本會不同，但沒有量測。
- 每個 WFT 約 134 µs，與 S0 中處理一個普通 WFT 的成本（110–140 µs）同一個數量級。也就是說，**一次重建約等於把該 run 的所有 WFT 再處理一次**。

## 5. 額外的 replay 與 LA 成本

### 5.1 Replay
- 每次只有 B 會發生的 eviction，代價為：
  - 1 次 `GetWorkflowExecutionHistory`（mock 中 1 頁，bytes 約等於完整 History）
  - (WFT 數 − 1) 個 replaying activations
  - 1 個 live activation
  - 1 個 RemoveFromCache activation
- 由於 latch 的語意（stage 18 報告），**每個被標記的 run instance 最多只因此重建一次**。新的 run 要再服務一次 effectful legacy query，才會再被標記。

### 5.2 LA 重新執行（依原始碼，不是實測窮舉）
- A 的 `can_reuse_after_legacy_query_effects`（`31a1a905` 中 `managed_run.rs` 約 1040–1045 行）只要有以下任一情況，就拒絕重用：
  - `deferred_local_resolutions` 不是空的
  - `waiting_on_la` 已設定
  - `has_executing_or_preresolved_local_activities()`
- 因此，只要有 LA 正在執行或結果被持有，A 也會 evict。**只有 B 會 evict 的情況中，不存在已執行而結果尚未 commit 的 LA**，所以不會重新執行 LA。
  - 已 commit 的 LA 由 marker replay，不會重新執行。
  - 準備期請求但從未派送的 LA（`new_requests`），兩個版本都在下一個 WFT 才第一次派送。B 的既有測試 `legacy_query_must_not_execute_local_activity` 的 cached 案例，斷言 LA「恰好派送一次」。
- **結論**：LA 重新執行只發生在 A、B 共同 evict 的情況（S4），每次 eviction 重新執行 1 次 LA。對照的「只有 B evict 而且帶 LA」workload，依上述原始碼論證無法合法建立，沒有人工製造不可達的狀態。

## 6. Workload-level sensitivity（假設模型，不是 production 量測）

設 p 為「真正的 WFT 中，因為只有 B 會觸發的 eviction 而需要重建」的比例。假設每次都付出 S2 實測的中位數 Δ，**平均每個 WFT 增加的 Core-level 處理延遲** = p × Δ(History)：

| p | 98 events | 998 events | 4,998 events | 9,998 events |
|---|---:|---:|---:|---:|
| 0.01% | 0.31 µs | 2.7 µs | 13 µs | 27 µs |
| 0.1% | 3.1 µs | 27 µs | 134 µs | 269 µs |
| 1% | 31 µs | 268 µs | 1.34 ms | 2.69 ms |
| 5% | 154 µs | 1.34 ms | 6.7 ms | 13.4 ms |
| 10% | 308 µs | 2.7 ms | 13.4 ms | 26.9 ms |

- 這是平均值。受影響的那些 WFT 本身，一次就要付出完整的 Δ（例如 10k events 時 +269 ms）。
- 不能由平均值推導 p99 或整體 throughput。
- p 的意義很窄。三個條件必須同時成立：
  - legacy query 抵達時，有尚未 started 的 WFT 所帶來的新 non-command events；
  - 準備期因此執行了 workflow code；
  - run 仍在 cache 中，而且下一個 WFT 本來可以被 A 安全地重用。
- 已經要 evict 的情況（S3、S4）不計入 p。

## 7. 已實測與仍未知

**已實測（Core-level、release、synthetic lang、in-memory mock）：**
- 下一個真正 WFT 的 latency：median、p95、p99（p99 只作參考）
- CPU time
- eviction 次數、activation 與 replay activation 次數
- History fetch 次數與 mock 編碼後的 bytes
- query 回覆延遲
- 完成相同工作的總時間
- LA 執行次數
- 粗略的 RSS
- S2 的 8 到 9,998 events scaling

**未實測或 unavailable：**
- **真實 Server**：gRPC 往返、Server persistence 讀取、History 分頁（mock 一次回傳全部）、protobuf decode（mock 直接回傳 struct，沒有 decode 成本）、TLS。
- **真正的 Language SDK**：例如 Python bridge 與 sandbox 每個 activation 的 replay 成本。它很可能遠高於 synthetic lang；而 Δ 與 activation 數成正比，所以 Core 數字是下界。
- **Throughput** 與多 workflow 併發下的 cache 壓力：unavailable，本 benchmark 一次只跑一個 workflow。
- **`disable_workflow_task_chunking`（unchunked）模式**：沒有量測。
- 重建時間對 **WFT timeout** 的影響：長 History 加上慢速 lang 時才可能需要注意，沒有量測。
- effectful legacy query 在真實環境中的發生率（p）。
- stage 18 已知的另一個代價：「cache miss 時由 legacy query 建立 run，而且最新的 WFT 尚未完成」。這個情況的頻率與成本沒有單獨量測。依機制，成本與 S2 相同，都是一次重建。

## 8. 限制

1. 所有數字是 Core-level 加 synthetic lang，在 6 vCPU 的 aarch64 VM 上以 release profile 量測，**不是 production latency**。
2. Mock 的 History fetch 不包含網路、資料庫、序列化與分頁成本。
3. **沒有執行真實 Server benchmark**。原因：
   - 方案 B 從未回移植到 Python SDK。要建立 bridge wheel，需要新的大型 build directory。
   - 本次開始時可用空間 28.33 GiB，建立本 benchmark 的 release target 用掉約 1.9 GiB，結束時為 26.37 GiB。
   - 在 25 GiB 的下限之內，已經沒有安全餘裕。
   - 依規定，以 Core-level 結果作為第一階段。
4. 只測了預設（chunked）模式，以及 timer cycle 這一種 workload 形狀。
5. S3 在約 5k events 的約 1% 差異，沒有找出機制。
6. S4 的 20 ms LA 比較中，n=30 且分布重疊，沒有結論。
7. RSS 受 allocator 影響很大。
8. 建置 tree 目前停在 U（最後一次建置）。三個 binary 都已保存，並記錄了 sha256。

## 9. 對六個問題的回答

1. **Conservative eviction 是否對普通 Hot Path 造成可量測影響？**
   沒有。S0 與 S1 在四種 History 規模下，B−A 都在 ±6 µs 以內，CI 包含 0，量測解析度約 ±10–20 µs。原始碼的變化為 O(1)。
2. **額外 eviction 的實測成本是多少？**
   在 Core-level，每次約 96 µs + 134 µs × WFT 數的牆鐘時間（CPU 約 105 µs/WFT），加上 1 次完整 History fetch，以及 WFT 數 + 1 個 activations。
   實測值：98 events +3.1 ms、998 events +26.8 ms、4,998 events +134 ms、9,998 events +269 ms。
3. **這個成本如何隨 History 長度改變？**
   在 2 到 2,000 個 WFT 之間，與 WFT 數線性相關（log-log 斜率 0.97，邊際成本穩定在約 134 µs/WFT）。大小等同於對該 run 做一次完整的冷重建。
4. **哪些成本已經實測，哪些仍然未知？**
   見 §7。真實 Server 的 fetch、Language SDK 的 replay 成本、併發下的 throughput、unchunked 模式、真實發生率，都仍然未知。
5. **現有結果是否支持 conservative eviction 作為合理的 correctness-first trade-off？**
   支持。理由：
   - hot path 與 non-effectful query 沒有可量測的成本；
   - 原本就要 evict 的路徑沒有政策層面的額外成本；
   - 只有 B 會 evict 的情況，成本有界：每個 run instance 每次 effectful legacy query 最多一次，大小等同於一次 cache miss；
   - 被移除的 predicate 已經有 History Length 反例證明不安全，而 U 在 S3、S4 會產生 NDE History。

   前提是：在長 History 的 workflow 上，effectful legacy query 不是常態。
6. **是否有具體數據顯示需要重新考慮目前設計？**
   沒有。目前沒有任何實測數據指向這個方向。需要重新考慮的條件是：「≥1,000 WFT 的 History」加上「effectful legacy query 占真實 WFT ≥1%」，此時平均每個 WFT 會增加約 1.3 ms 以上（Core-level，真實環境會更高），而受影響的 WFT 本身會增加數百毫秒。
   這些成本都會落在 B 新加入、有專屬訊息的 eviction 上（`Legacy query ran workflow code on history no workflow task has committed`）。若要取得 p 的真實資料，可以統計這則訊息的 eviction 次數。

## 10. English summary for maintainers

> **Cost of the conservative legacy-query eviction (#1766), Core-level measurement**
>
> - **Method.** Exact U (`6eaaeeba`), A (`31a1a905`, conditional reuse) and B (`9a59ba3c3`, production diff sha256 `35f5f0c7…`) trees, plus one identical lib-test benchmark module. All three were built with the same release profile and toolchain.
> - **Harness.** Mocked server and a trivial synthetic lang. The next real workflow task arrives as a sticky incremental task. Runs were interleaved ABBA style: 60–100 samples per cell, after warm-up.
> - **Correctness.** Each cell was cold-replayed separately on a fresh replay worker. A and B always replayed. U produced nondeterminism errors in the signal, update and held-local-activity scenarios, so its speed there is not counted.
>
> - **No hot-path cost.** Normal tasks and legacy queries that run no workflow code show no measurable difference: |Δmedian| ≤ 6 µs, CIs include 0, at 98–9,998 events.
> - **Cost of the extra eviction.** An effectful legacy query followed by a task with no new work is the only case where B evicts and A did not. B then rebuilds the run: one full history fetch and a replay of every workflow task. In Core this costs about **134 µs of wall time (105 µs of CPU) per workflow task in history, plus about 0.1 ms**. That is +3.1 ms at 98 events, +27 ms at 998, +134 ms at 4,998 and +269 ms at 9,998. Growth is linear (log-log slope 0.97), and the cost equals one ordinary cache miss for that run. It happens at most once per run instance per effectful legacy query.
> - **Paths that already evicted.** These are a signal or update in the next task, or a held local-activity result. B adds no extra work there: same evictions, activations, fetches, and local-activity executions (two, of which one is a re-execution, in both A and B). A residual ~1% difference at ~5k events has no source-level cause.
> - **No extra local-activity re-execution.** A's reuse predicate already refused reuse whenever a local activity was executing, held or deferred. So B-only evictions never re-run a local activity (argued from source).
> - **Not measured.** Real server RPC, persistence and pagination; language SDK replay cost (likely larger than Core's, and multiplied by the same activation count); unchunked mode; throughput under concurrency; and the real-world frequency of effectful legacy queries.
> - **Sensitivity (assumed rates).** At 1% of tasks hitting a B-only eviction, the mean added Core latency per task is 31 µs at 98 events and 2.7 ms at 9,998 events.
> - **Verdict.** The data supports the conservative policy as a correctness-first trade-off. Only frequent effectful legacy queries on long histories would make the cost significant. The eviction message is unique, so production frequency can be measured from it.

## 11. 檔案與操作紀錄

Investigation directory：`~/oss/investigations/sdk-rust-1766-perf-20261125/`

| 路徑 | 內容 |
|---|---|
| `bench/perf_bench_1766.rs` | benchmark 原始碼 |
| `scripts/` | `install_bench.sh`、`check_identity.sh`、`build.sh`（含 25.3 GiB 的磁碟保護）、`disk_guard.sh`、`run_matrix.sh`、`run_all.sh`、`analyze.py`、`verify_summary.py`、`scaling.py` |
| `raw/timed.jsonl` | 5,742 個計時樣本（含 warm-up 列，`warmup=true`） |
| `raw/verify.jsonl` | 189 個 correctness 樣本 |
| `raw/*_summary.md`、`raw/scaling.md` | 由上列腳本產生的摘要 |
| `raw/build_*.log`、`raw/build_*.json` | 建置紀錄 |
| `raw/stderr_*.log` | 全部為空 |
| `raw/smoke/` | 初期 smoke test，不列入統計 |
| `evidence/identity_{U,A,B}.txt`、`evidence/environment.txt` | source identity 與環境紀錄 |
| `bins/{A,B,U}/sdk_core_lib_tests` | 量測用 binary |
| `tree/` | 建置用的 source tree |
| `target/` | 本次新建的 release target，約 1.9 GiB |
| `MANIFEST.txt` | 上述檔案的 sha256 |

- 沒有修改正式 worktree 的任何檔案，也沒有修改正式的回歸測試。
- 沒有 commit、push、PR 或 GitHub 留言。
- 沒有刪除任何 #1766 target、incremental cache 或既有證據。
- 磁碟：開始 28.33 GiB，結束 26.37 GiB。
