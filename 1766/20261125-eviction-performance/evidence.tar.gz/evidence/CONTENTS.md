# evidence/

Saved outputs of the original run (2026-11-25), byte-for-byte as produced. Nothing was edited.

- `raw/verify.jsonl` - correctness pass: 189 rows (`verify=true`), each live run followed by a cold replay.
- `raw/timed.jsonl` - timed matrix: 5,742 rows, of which 1,332 are warm-up rows (`warmup=true`) and
  4,410 are measurements. No row was removed.
- `raw/run_all.log` - start/end times of the two passes; `raw/stderr_*.log` - stderr of every benchmark
  process (all empty).
- `raw/build_{A,B,U}.log|json` - Cargo output of the three builds, including the profile and feature
  set of the measured test binary and its sha256 after copying.
- `raw/timed_summary.md`, `raw/scaling.md`, `raw/verify_summary.md` - tables printed by the analysis
  scripts at the time; `verify.py` recomputes them.
- `raw/smoke/` - exploratory smoke runs made before the matrix (2-3 samples each); not used in any
  statistic.
- `identity/identity_{U,A,B}.txt` - tree-versus-commit identity check of each build tree.
- `identity/environment.txt` - environment recorded right after the run;
  `identity/environment_packaging.txt` - extra hardware details collected when packaging.
- `provenance/MANIFEST.original.txt` - sha256 manifest written when the investigation ended. Paths
  map to this package as: `raw/` -> `evidence/raw/`, `evidence/` -> `evidence/identity/`,
  `scripts/` -> `evidence/provenance/scripts_as_executed/`, `REPORT_performance.md` ->
  `evidence/provenance/REPORT_performance.zh-TW.md`, `bench/` -> `reproducer/bench/`. The three
  `bins/` entries are compiled test binaries and are not distributed.
- `provenance/REPORT_performance.zh-TW.md` - the original (Traditional Chinese) report. Corrections
  found while packaging are listed in `results.json` under `discrepancies`.
- `provenance/scripts_as_executed/` - the scripts exactly as run, with the original absolute
  paths. The portable versions are in `reproducer/scripts/`.
