
### s0 cycles=18 la_delay_ms=0 hist_events=98 hist_bytes=2623 wft_count=20 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 120.8 | 200.1 | 212.8 | 127.1 | 133.6 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 121.0 | 246.1 | 281.5 | 139.6 | 138.7 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 128.8 | 232.9 | 249.7 | 142.4 | 134.4 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = +0.2 µs (95% bootstrap CI -7.8 … +21.5), ratio 1.002, MWU p = 0.216; CPU median Δ = +5.1 µs, ratio 1.038
- U vs A: median Δ = +8.0 µs (95% bootstrap CI -6.0 … +27.7), ratio 1.066, MWU p = 0.0851; CPU median Δ = +0.8 µs, ratio 1.006

### s0 cycles=198 la_delay_ms=0 hist_events=998 hist_bytes=27967 wft_count=200 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 110.0 | 145.4 | 179.7 | 114.2 | 155.8 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 114.4 | 131.2 | 176.1 | 115.1 | 152.5 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 118.5 | 161.4 | 172.6 | 119.6 | 159.5 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = +4.4 µs (95% bootstrap CI -2.7 … +9.6), ratio 1.040, MWU p = 0.49; CPU median Δ = -3.2 µs, ratio 0.979
- U vs A: median Δ = +8.4 µs (95% bootstrap CI -0.8 … +12.7), ratio 1.077, MWU p = 0.158; CPU median Δ = +3.8 µs, ratio 1.024

### s0 cycles=998 la_delay_ms=0 hist_events=4998 hist_bytes=142239 wft_count=1000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 118.2 | 153.3 | 216.2 | 124.6 | 181.7 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 123.9 | 170.4 | 230.9 | 130.3 | 188.2 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 120.2 | 157.4 | 166.8 | 123.1 | 190.6 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = +5.7 µs (95% bootstrap CI -1.8 … +12.6), ratio 1.048, MWU p = 0.123; CPU median Δ = +6.5 µs, ratio 1.036
- U vs A: median Δ = +2.1 µs (95% bootstrap CI -7.1 … +8.6), ratio 1.017, MWU p = 0.828; CPU median Δ = +8.9 µs, ratio 1.049

### s0 cycles=1998 la_delay_ms=0 hist_events=9998 hist_bytes=269046 wft_count=2000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 138.2 | 187.4 | 197.8 | 141.8 | 202.6 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 139.9 | 185.7 | 192.0 | 143.0 | 206.8 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 136.2 | 189.6 | 218.1 | 140.5 | 201.2 | nan | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = +1.6 µs (95% bootstrap CI -5.1 … +11.2), ratio 1.012, MWU p = 0.474; CPU median Δ = +4.2 µs, ratio 1.021
- U vs A: median Δ = -2.1 µs (95% bootstrap CI -9.4 … +7.9), ratio 0.985, MWU p = 0.583; CPU median Δ = -1.4 µs, ratio 0.993

### s1 cycles=18 la_delay_ms=0 hist_events=98 hist_bytes=2623 wft_count=20 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 130.3 | 197.8 | 299.1 | 140.4 | 137.3 | 245.8 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 128.4 | 194.9 | 233.8 | 132.9 | 144.8 | 250.6 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 124.5 | 194.7 | 219.8 | 131.0 | 135.8 | 244.7 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = -2.0 µs (95% bootstrap CI -9.7 … +10.4), ratio 0.985, MWU p = 0.611; CPU median Δ = +7.5 µs, ratio 1.054
- U vs A: median Δ = -5.8 µs (95% bootstrap CI -13.0 … +6.6), ratio 0.955, MWU p = 0.386; CPU median Δ = -1.5 µs, ratio 0.989

### s1 cycles=198 la_delay_ms=0 hist_events=998 hist_bytes=27967 wft_count=200 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 118.8 | 155.5 | 239.2 | 124.6 | 169.9 | 318.5 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 118.2 | 160.2 | 167.3 | 120.0 | 167.7 | 311.9 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 120.3 | 170.1 | 183.3 | 125.4 | 169.4 | 306.7 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = -0.6 µs (95% bootstrap CI -6.4 … +4.2), ratio 0.995, MWU p = 0.567; CPU median Δ = -2.2 µs, ratio 0.987
- U vs A: median Δ = +1.6 µs (95% bootstrap CI -5.0 … +6.9), ratio 1.013, MWU p = 0.838; CPU median Δ = -0.5 µs, ratio 0.997

### s1 cycles=998 la_delay_ms=0 hist_events=4998 hist_bytes=142239 wft_count=1000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 132.8 | 180.4 | 211.1 | 136.5 | 196.4 | 730.4 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 131.4 | 190.3 | 248.0 | 139.3 | 197.4 | 744.5 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 132.0 | 188.7 | 233.1 | 139.1 | 201.3 | 739.3 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = -1.4 µs (95% bootstrap CI -9.5 … +5.9), ratio 0.989, MWU p = 0.973; CPU median Δ = +1.0 µs, ratio 1.005
- U vs A: median Δ = -0.8 µs (95% bootstrap CI -9.8 … +8.5), ratio 0.994, MWU p = 0.896; CPU median Δ = +4.9 µs, ratio 1.025

### s1 cycles=1998 la_delay_ms=0 hist_events=9998 hist_bytes=287237 wft_count=2000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 159.6 | 208.7 | 241.3 | 163.3 | 222.6 | 1314.1 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 161.7 | 287.9 | 399.1 | 176.4 | 223.9 | 1327.9 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 157.4 | 196.4 | 291.7 | 162.8 | 225.7 | 1335.2 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×60 |
- B vs A: median Δ = +2.1 µs (95% bootstrap CI -3.0 … +9.4), ratio 1.013, MWU p = 0.277; CPU median Δ = +1.2 µs, ratio 1.005
- U vs A: median Δ = -2.2 µs (95% bootstrap CI -6.4 … +4.5), ratio 0.986, MWU p = 0.673; CPU median Δ = +3.1 µs, ratio 1.014

### s2 cycles=0 la_delay_ms=0 hist_events=8 hist_bytes=283 wft_count=2 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 100 | 144.4 | 247.0 | 329.2 | 154.2 | 132.3 | 309.7 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| B | 100 | 480.6 | 803.0 | 836.5 | 513.8 | 367.1 | 295.5 | 1×100 | 3×100 | 1×100 | 1×100 | 270×2,278×44,286×54 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| U | 100 | 161.8 | 290.2 | 326.5 | 170.2 | 136.6 | 364.8 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
- B vs A: median Δ = +336.1 µs (95% bootstrap CI +299.7 … +368.9), ratio 3.327, MWU p = 5.03e-34; CPU median Δ = +234.9 µs, ratio 2.776
- U vs A: median Δ = +17.4 µs (95% bootstrap CI -1.9 … +36.8), ratio 1.120, MWU p = 0.0509; CPU median Δ = +4.3 µs, ratio 1.032

### s2 cycles=18 la_delay_ms=0 hist_events=98 hist_bytes=2623 wft_count=20 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 100 | 110.1 | 215.8 | 269.8 | 126.4 | 116.3 | 263.6 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| B | 100 | 3195.0 | 4074.3 | 5260.7 | 3297.1 | 2398.1 | 277.6 | 1×100 | 21×100 | 19×100 | 1×100 | 2528×21,2626×79 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| U | 100 | 115.5 | 191.9 | 223.5 | 126.1 | 114.6 | 264.5 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
- B vs A: median Δ = +3084.9 µs (95% bootstrap CI +3024.5 … +3184.2), ratio 29.028, MWU p = 2.52e-34; CPU median Δ = +2281.8 µs, ratio 20.614
- U vs A: median Δ = +5.5 µs (95% bootstrap CI -5.8 … +17.3), ratio 1.050, MWU p = 0.321; CPU median Δ = -1.7 µs, ratio 0.985

### s2 cycles=198 la_delay_ms=0 hist_events=998 hist_bytes=27967 wft_count=200 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 100 | 111.6 | 155.6 | 211.8 | 116.0 | 147.4 | 328.0 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| B | 100 | 26883.9 | 29952.2 | 32451.4 | 27322.9 | 21075.6 | 373.8 | 1×100 | 201×100 | 199×100 | 1×100 | 26973×26,27971×74 | 0×100 | 18 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| U | 100 | 109.8 | 177.5 | 222.3 | 114.8 | 144.0 | 328.1 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
- B vs A: median Δ = +26772.2 µs (95% bootstrap CI +26626.1 … +26918.3), ratio 240.793, MWU p = 2.52e-34; CPU median Δ = +20928.2 µs, ratio 142.966
- U vs A: median Δ = -1.9 µs (95% bootstrap CI -8.6 … +3.0), ratio 0.983, MWU p = 0.0796; CPU median Δ = -3.4 µs, ratio 0.977

### s2 cycles=998 la_delay_ms=0 hist_events=4998 hist_bytes=142230 wft_count=1000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 100 | 124.6 | 167.6 | 202.8 | 128.6 | 175.0 | 742.9 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| B | 100 | 134381.7 | 139755.1 | 150149.8 | 134801.0 | 104867.4 | 735.9 | 1×100 | 1001×100 | 999×100 | 1×100 | 137245×29,142243×71 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| U | 100 | 121.8 | 184.8 | 201.2 | 126.5 | 176.7 | 749.2 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
- B vs A: median Δ = +134257.1 µs (95% bootstrap CI +133614.7 … +134626.7), ratio 1078.821, MWU p = 2.52e-34; CPU median Δ = +104692.3 µs, ratio 599.174
- U vs A: median Δ = -2.8 µs (95% bootstrap CI -7.1 … +1.5), ratio 0.978, MWU p = 0.16; CPU median Δ = +1.7 µs, ratio 1.010

### s2 cycles=1998 la_delay_ms=0 hist_events=9998 hist_bytes=287237 wft_count=2000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 100 | 148.4 | 202.3 | 223.2 | 152.0 | 201.3 | 1352.4 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| B | 100 | 269057.6 | 281706.4 | 288131.6 | 267022.3 | 209812.3 | 1350.8 | 1×100 | 2001×100 | 1999×100 | 1×100 | 277243×22,282132×1,287241×77 | 0×100 | 20032 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
| U | 100 | 143.8 | 194.1 | 215.2 | 147.5 | 198.8 | 1314.4 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0×100 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES×100 |
- B vs A: median Δ = +268909.2 µs (95% bootstrap CI +266232.7 … +270218.3), ratio 1813.606, MWU p = 2.52e-34; CPU median Δ = +209611.0 µs, ratio 1042.225
- U vs A: median Δ = -4.6 µs (95% bootstrap CI -8.9 … +0.4), ratio 0.969, MWU p = 0.189; CPU median Δ = -2.5 µs, ratio 0.988

### s3sig cycles=18 la_delay_ms=0 hist_events=99 hist_bytes=2555 wft_count=20 partial_events=6
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 3288.3 | 4093.0 | 4523.2 | 3363.2 | 2439.1 | 280.6 | 1×60 | 21×60 | 19×60 | 1×60 | 2558×30,2657×30 | 0×60 | 0 | 0 | START_TIMER+MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 3238.4 | 3790.8 | 3911.7 | 3274.1 | 2426.9 | 283.4 | 1×60 | 21×60 | 19×60 | 1×60 | 2558×14,2657×46 | 0×60 | 0 | 0 | START_TIMER+MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 131.2 | 234.7 | 277.5 | 145.9 | 143.3 | 277.6 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES+START_TIMER×60 |
- B vs A: median Δ = -49.9 µs (95% bootstrap CI -245.3 … +147.6), ratio 0.985, MWU p = 0.332; CPU median Δ = -12.3 µs, ratio 0.995
- U vs A: median Δ = -3157.2 µs (95% bootstrap CI -3329.7 … -3030.4), ratio 0.040, MWU p = 3.47e-21; CPU median Δ = -2295.8 µs, ratio 0.059

### s3sig cycles=198 la_delay_ms=0 hist_events=999 hist_bytes=27999 wft_count=200 partial_events=6
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 26650.9 | 28147.4 | 28546.5 | 26683.5 | 20966.6 | 347.0 | 1×60 | 201×60 | 199×60 | 1×60 | 27004×26,28003×34 | 0×60 | 0 | 0 | START_TIMER+MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 26866.4 | 28260.8 | 28483.6 | 26921.2 | 21038.2 | 339.4 | 1×60 | 201×60 | 199×60 | 1×60 | 27004×14,28003×46 | 0×60 | 4 | 0 | START_TIMER+MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 120.3 | 189.6 | 278.7 | 129.0 | 162.6 | 336.2 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES+START_TIMER×60 |
- B vs A: median Δ = +215.5 µs (95% bootstrap CI -33.1 … +482.7), ratio 1.008, MWU p = 0.0237; CPU median Δ = +71.6 µs, ratio 1.003
- U vs A: median Δ = -26530.6 µs (95% bootstrap CI -26666.9 … -26343.8), ratio 0.005, MWU p = 3.47e-21; CPU median Δ = -20803.9 µs, ratio 0.008

### s3sig cycles=998 la_delay_ms=0 hist_events=4999 hist_bytes=137272 wft_count=1000 partial_events=6
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 133235.0 | 141284.4 | 148876.9 | 134424.1 | 104538.7 | 753.2 | 1×60 | 1001×60 | 999×60 | 1×60 | 137276×13,142271×1,142275×46 | 0×60 | 0 | 0 | START_TIMER+MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 134371.5 | 138507.7 | 159100.6 | 135216.5 | 105402.1 | 741.6 | 1×60 | 1001×60 | 999×60 | 1×60 | 137276×15,137278×1,142271×2,142275×42 | 0×60 | 0 | 0 | START_TIMER+MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 132.2 | 192.3 | 205.2 | 139.5 | 199.0 | 759.9 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES+START_TIMER×60 |
- B vs A: median Δ = +1136.5 µs (95% bootstrap CI +143.8 … +1778.4), ratio 1.009, MWU p = 0.0428; CPU median Δ = +863.4 µs, ratio 1.008
- U vs A: median Δ = -133102.8 µs (95% bootstrap CI -133913.4 … -132606.7), ratio 0.001, MWU p = 3.47e-21; CPU median Δ = -104339.7 µs, ratio 0.002

### s3upd cycles=18 la_delay_ms=0 hist_events=98 hist_bytes=2623 wft_count=20 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 3128.3 | 3930.9 | 4175.8 | 3227.8 | 2381.0 | 279.8 | 1×60 | 21×60 | 19×60 | 1×60 | 2528×5,2626×55 | 0×60 | 0 | 0 | PROTOCOL_MESSAGE+PROTOCOL_MESSAGE+MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 3293.6 | 4079.3 | 4127.4 | 3366.6 | 2456.8 | 274.7 | 1×60 | 21×60 | 19×60 | 1×60 | 2528×10,2626×50 | 0×60 | 0 | 0 | PROTOCOL_MESSAGE+PROTOCOL_MESSAGE+MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 140.2 | 237.3 | 352.5 | 155.6 | 152.1 | 278.1 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES+PROTOCOL_MESSAGE+PROTOCOL_MESSAGE×60 |
- B vs A: median Δ = +165.3 µs (95% bootstrap CI -90.7 … +454.5), ratio 1.053, MWU p = 0.0617; CPU median Δ = +75.7 µs, ratio 1.032
- U vs A: median Δ = -2988.1 µs (95% bootstrap CI -3206.3 … -2829.1), ratio 0.045, MWU p = 3.47e-21; CPU median Δ = -2228.9 µs, ratio 0.064

### s3upd cycles=198 la_delay_ms=0 hist_events=998 hist_bytes=26969 wft_count=200 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 26808.9 | 27649.7 | 28022.7 | 26766.2 | 20962.7 | 359.3 | 1×60 | 201×60 | 199×60 | 1×60 | 26973×27,27971×33 | 0×60 | 4 | 0 | PROTOCOL_MESSAGE+PROTOCOL_MESSAGE+MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 26706.0 | 29254.6 | 34598.4 | 27165.7 | 21121.8 | 333.4 | 1×60 | 201×60 | 199×60 | 1×60 | 26973×15,27971×45 | 0×60 | 4 | 0 | PROTOCOL_MESSAGE+PROTOCOL_MESSAGE+MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 129.8 | 174.8 | 187.2 | 131.6 | 171.4 | 313.9 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES+PROTOCOL_MESSAGE+PROTOCOL_MESSAGE×60 |
- B vs A: median Δ = -102.9 µs (95% bootstrap CI -334.4 … +560.4), ratio 0.996, MWU p = 0.253; CPU median Δ = +159.1 µs, ratio 1.008
- U vs A: median Δ = -26679.1 µs (95% bootstrap CI -26885.2 … -26335.0), ratio 0.005, MWU p = 3.47e-21; CPU median Δ = -20791.3 µs, ratio 0.008

### s3upd cycles=998 la_delay_ms=0 hist_events=4998 hist_bytes=142239 wft_count=1000 partial_events=5
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 60 | 132790.5 | 137526.9 | 141217.1 | 132773.1 | 104429.6 | 732.1 | 1×60 | 1001×60 | 999×60 | 1×60 | 137245×12,137246×1,137250×2,142241×1,142243×44 | 0×60 | 0 | 0 | PROTOCOL_MESSAGE+PROTOCOL_MESSAGE+MODIFY_WORKFLOW_PROPERTIES×60 |
| B | 60 | 134745.1 | 141463.9 | 148783.6 | 134690.6 | 105348.1 | 744.7 | 1×60 | 1001×60 | 999×60 | 1×60 | 132252×1,137245×14,142241×1,142243×44 | 0×60 | 0 | 0 | PROTOCOL_MESSAGE+PROTOCOL_MESSAGE+MODIFY_WORKFLOW_PROPERTIES×60 |
| U | 60 | 138.9 | 192.6 | 228.3 | 145.4 | 207.3 | 738.8 | 0×60 | 1×60 | 0×60 | 0×60 | 0×60 | 0×60 | 0 | 0 | MODIFY_WORKFLOW_PROPERTIES+PROTOCOL_MESSAGE+PROTOCOL_MESSAGE×60 |
- B vs A: median Δ = +1954.6 µs (95% bootstrap CI +817.7 … +2810.1), ratio 1.015, MWU p = 0.0015; CPU median Δ = +918.5 µs, ratio 1.009
- U vs A: median Δ = -132651.6 µs (95% bootstrap CI -133596.6 … -132192.2), ratio 0.001, MWU p = 3.47e-21; CPU median Δ = -104222.3 µs, ratio 0.002

### s4 cycles=0 la_delay_ms=0 hist_events=13 hist_bytes=440 wft_count=3 partial_events=13
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 100 | 689.1 | 1062.7 | 1173.7 | 721.5 | 579.1 | 271.8 | 1×100 | 4×52,5×48 | 2×100 | 0×100 | 0×100 | 1×100 | 16 | 0 | MODIFY_WORKFLOW_PROPERTIES+RECORD_MARKER×48,RECORD_MARKER+START_TIMER×52 |
| B | 100 | 703.4 | 1029.9 | 1185.6 | 722.7 | 596.3 | 272.2 | 1×100 | 4×47,5×53 | 2×100 | 0×100 | 0×100 | 1×100 | 24 | 0 | MODIFY_WORKFLOW_PROPERTIES+RECORD_MARKER×53,RECORD_MARKER+START_TIMER×47 |
| U | 100 | 180.1 | 313.4 | 424.1 | 199.2 | 201.7 | 311.5 | 0×100 | 1×100 | 0×100 | 0×100 | 0×100 | 0×100 | 8 | 0 | MODIFY_WORKFLOW_PROPERTIES+RECORD_MARKER×100 |
- B vs A: median Δ = +14.2 µs (95% bootstrap CI -36.8 … +59.4), ratio 1.021, MWU p = 0.584; CPU median Δ = +17.2 µs, ratio 1.030
- U vs A: median Δ = -509.1 µs (95% bootstrap CI -557.8 … -479.6), ratio 0.261, MWU p = 2.52e-34; CPU median Δ = -377.4 µs, ratio 0.348

### s4 cycles=0 la_delay_ms=20 hist_events=13 hist_bytes=440 wft_count=3 partial_events=13
| label | n | median µs | p95 µs | p99 µs | mean µs | cpu median µs | q_lat median µs | win evicts | win acts | win replay acts | win fetches | fetch bytes | LA exec (win) | hwm-rss0 median KiB | failures | real cmds |
|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|---|---|---:|---:|---|
| A | 30 | 27378.3 | 32662.7 | 33029.7 | 27405.0 | 2058.2 | 599.5 | 1×30 | 5×30 | 2×30 | 0×30 | 0×30 | 1×30 | 16 | 0 | MODIFY_WORKFLOW_PROPERTIES+RECORD_MARKER×30 |
| B | 30 | 30866.9 | 33402.9 | 34044.7 | 29159.4 | 2223.1 | 678.0 | 1×30 | 5×30 | 2×30 | 0×30 | 0×30 | 1×30 | 16 | 0 | MODIFY_WORKFLOW_PROPERTIES+RECORD_MARKER×30 |
| U | 30 | 222.3 | 439.5 | 461.5 | 259.2 | 316.4 | 382.6 | 0×30 | 1×30 | 0×30 | 0×30 | 0×30 | 0×30 | 8 | 0 | MODIFY_WORKFLOW_PROPERTIES+RECORD_MARKER×30 |
- B vs A: median Δ = +3488.6 µs (95% bootstrap CI +351.4 … +6339.7), ratio 1.127, MWU p = 0.0668; CPU median Δ = +164.9 µs, ratio 1.080
- U vs A: median Δ = -27156.0 µs (95% bootstrap CI -28827.5 … -24749.2), ratio 0.008, MWU p = 2.87e-11; CPU median Δ = -1741.8 µs, ratio 0.154
